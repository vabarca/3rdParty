



<!DOCTYPE html>
<html>
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" >
 <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
 
 <meta name="ROBOTS" content="NOARCHIVE">
 
 <link rel="icon" type="image/vnd.microsoft.icon" href="https://ssl.gstatic.com/codesite/ph/images/phosting.ico">
 
 
 <script type="text/javascript">
 
 
 
 
 var codesite_token = "ABZ6GAdrqaOtRuoQey-ncYnTETaHeQWmGg:1412118235326";
 
 
 var CS_env = {"loggedInUserEmail": "viabfer@gmail.com", "assetHostPath": "https://ssl.gstatic.com/codesite/ph", "assetVersionPath": "https://ssl.gstatic.com/codesite/ph/16315335801608708296", "domainName": null, "relativeBaseUrl": "", "token": "ABZ6GAdrqaOtRuoQey-ncYnTETaHeQWmGg:1412118235326", "profileUrl": "/u/114812766044642662008/", "projectHomeUrl": "/p/openxvario", "projectName": "openxvario"};
 var _gaq = _gaq || [];
 _gaq.push(
 ['siteTracker._setAccount', 'UA-18071-1'],
 ['siteTracker._trackPageview']);
 
 _gaq.push(
 ['projectTracker._setAccount', 'UA-38000266-1'],
 ['projectTracker._trackPageview']);
 
 (function() {
 var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
 ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
 (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(ga);
 })();
 
 </script>
 
 
 <title>oxs_config.h - 
 openxvario -
 
 
 An arduino based Vario and Sensor hub for open9X - Google Project Hosting
 </title>
 <link type="text/css" rel="stylesheet" href="https://ssl.gstatic.com/codesite/ph/16315335801608708296/css/core.css">
 
 <link type="text/css" rel="stylesheet" href="https://ssl.gstatic.com/codesite/ph/16315335801608708296/css/ph_detail.css" >
 
 
 <link type="text/css" rel="stylesheet" href="https://ssl.gstatic.com/codesite/ph/16315335801608708296/css/d_sb.css" >
 
 
 
<!--[if IE]>
 <link type="text/css" rel="stylesheet" href="https://ssl.gstatic.com/codesite/ph/16315335801608708296/css/d_ie.css" >
<![endif]-->
 <style type="text/css">
 .menuIcon.off { background: no-repeat url(https://ssl.gstatic.com/codesite/ph/images/dropdown_sprite.gif) 0 -42px }
 .menuIcon.on { background: no-repeat url(https://ssl.gstatic.com/codesite/ph/images/dropdown_sprite.gif) 0 -28px }
 .menuIcon.down { background: no-repeat url(https://ssl.gstatic.com/codesite/ph/images/dropdown_sprite.gif) 0 0; }
 
 
 
  tr.inline_comment {
 background: #fff;
 vertical-align: top;
 }
 div.draft, div.published {
 padding: .3em;
 border: 1px solid #999; 
 margin-bottom: .1em;
 font-family: arial, sans-serif;
 max-width: 60em;
 }
 div.draft {
 background: #ffa;
 } 
 div.published {
 background: #e5ecf9;
 }
 div.published .body, div.draft .body {
 padding: .5em .1em .1em .1em;
 max-width: 60em;
 white-space: pre-wrap;
 white-space: -moz-pre-wrap;
 white-space: -pre-wrap;
 white-space: -o-pre-wrap;
 word-wrap: break-word;
 font-size: 1em;
 }
 div.draft .actions {
 margin-left: 1em;
 font-size: 90%;
 }
 div.draft form {
 padding: .5em .5em .5em 0;
 }
 div.draft textarea, div.published textarea {
 width: 95%;
 height: 10em;
 font-family: arial, sans-serif;
 margin-bottom: .5em;
 }

 
 .nocursor, .nocursor td, .cursor_hidden, .cursor_hidden td {
 background-color: white;
 height: 2px;
 }
 .cursor, .cursor td {
 background-color: darkblue;
 height: 2px;
 display: '';
 }
 
 
.list {
 border: 1px solid white;
 border-bottom: 0;
}

 
 </style>
</head>
<body class="t4">
<script type="text/javascript">
 window.___gcfg = {lang: 'en'};
 (function() 
 {var po = document.createElement("script");
 po.type = "text/javascript"; po.async = true;po.src = "https://apis.google.com/js/plusone.js";
 var s = document.getElementsByTagName("script")[0];
 s.parentNode.insertBefore(po, s);
 })();
</script>
<div class="headbg">

 <div id="gaia">
 

 <span>
 
 
 
 <a href="#" id="multilogin-dropdown" onclick="return false;"
 ><u><b>viabfer@gmail.com</b></u> <small>&#9660;</small></a>
 
 
 | <a href="/u/114812766044642662008/" id="projects-dropdown" onclick="return false;"
 ><u>My favorites</u> <small>&#9660;</small></a>
 | <a href="/u/114812766044642662008/" onclick="_CS_click('/gb/ph/profile');"
 title="Profile, Updates, and Settings"
 ><u>Profile</u></a>
 | <a href="https://www.google.com/accounts/Logout?continue=https%3A%2F%2Fcode.google.com%2Fp%2Fopenxvario%2Fsource%2Fbrowse%2Fbranches%2Fopenxsensor%2Foxs_config.h" 
 onclick="_CS_click('/gb/ph/signout');"
 ><u>Sign out</u></a>
 
 </span>

 </div>

 <div class="gbh" style="left: 0pt;"></div>
 <div class="gbh" style="right: 0pt;"></div>
 
 
 <div style="height: 1px"></div>
<!--[if lte IE 7]>
<div style="text-align:center;">
Your version of Internet Explorer is not supported. Try a browser that
contributes to open source, such as <a href="http://www.firefox.com">Firefox</a>,
<a href="http://www.google.com/chrome">Google Chrome</a>, or
<a href="http://code.google.com/chrome/chromeframe/">Google Chrome Frame</a>.
</div>
<![endif]-->



 <table style="padding:0px; margin: 0px 0px 10px 0px; width:100%" cellpadding="0" cellspacing="0"
 itemscope itemtype="http://schema.org/CreativeWork">
 <tr style="height: 58px;">
 
 
 
 <td id="plogo">
 <link itemprop="url" href="/p/openxvario">
 <a href="/p/openxvario/">
 
 
 <img src="/p/openxvario/logo?cct=1408452668"
 alt="Logo" itemprop="image">
 
 </a>
 </td>
 
 <td style="padding-left: 0.5em">
 
 <div id="pname">
 <a href="/p/openxvario/"><span itemprop="name">openxvario</span></a>
 </div>
 
 <div id="psum">
 <a id="project_summary_link"
 href="/p/openxvario/"><span itemprop="description">An arduino based Vario and Sensor hub for open9X</span></a>
 
 </div>
 
 
 </td>
 <td style="white-space:nowrap;text-align:right; vertical-align:bottom;">
 
 <form action="/hosting/search">
 <input size="30" name="q" value="" type="text">
 
 <input type="submit" name="projectsearch" value="Search projects" >
 </form>
 
 </tr>
 </table>

</div>

 
<div id="mt" class="gtb"> 
 <a href="/p/openxvario/" class="tab ">Project&nbsp;Home</a>
 
 
 
 
 
 
 <a href="/p/openxvario/w/list" class="tab ">Wiki</a>
 
 
 
 
 
 <a href="/p/openxvario/issues/list"
 class="tab ">Issues</a>
 
 
 
 
 
 <a href="/p/openxvario/source/checkout"
 class="tab active">Source</a>
 
 
 
 
 
 
 
 
 <div class=gtbc></div>
</div>
<table cellspacing="0" cellpadding="0" width="100%" align="center" border="0" class="st">
 <tr>
 
 
 
 
 
 
 <td class="subt">
 <div class="st2">
 <div class="isf">
 
 


 <span class="inst1"><a href="/p/openxvario/source/checkout">Checkout</a></span> &nbsp;
 <span class="inst2"><a href="/p/openxvario/source/browse/">Browse</a></span> &nbsp;
 <span class="inst3"><a href="/p/openxvario/source/list">Changes</a></span> &nbsp;
 
 
 
 
 
 
 
 </form>
 <script type="text/javascript">
 
 function codesearchQuery(form) {
 var query = document.getElementById('q').value;
 if (query) { form.action += '%20' + query; }
 }
 </script>
 </div>
</div>

 </td>
 
 
 
 <td align="right" valign="top" class="bevel-right"></td>
 </tr>
</table>


<script type="text/javascript">
 var cancelBubble = false;
 function _go(url) { document.location = url; }
</script>
<div id="maincol"
 
>

 




<div class="expand">
<div id="colcontrol">
<style type="text/css">
 #file_flipper { white-space: nowrap; padding-right: 2em; }
 #file_flipper.hidden { display: none; }
 #file_flipper .pagelink { color: #0000CC; text-decoration: underline; }
 #file_flipper #visiblefiles { padding-left: 0.5em; padding-right: 0.5em; }
</style>
<table id="nav_and_rev" class="list"
 cellpadding="0" cellspacing="0" width="100%">
 <tr>
 
 <td nowrap="nowrap" class="src_crumbs src_nav" width="33%">
 <strong class="src_nav">Source path:&nbsp;</strong>
 <span id="crumb_root">
 
 <a href="/p/openxvario/source/browse/">svn</a>/&nbsp;</span>
 <span id="crumb_links" class="ifClosed"><a href="/p/openxvario/source/browse/branches/">branches</a><span class="sp">/&nbsp;</span><a href="/p/openxvario/source/browse/branches/openxsensor/">openxsensor</a><span class="sp">/&nbsp;</span>oxs_config.h</span>
 
 


 </td>
 
 
 <td nowrap="nowrap" width="33%" align="right">
 <table cellpadding="0" cellspacing="0" style="font-size: 100%"><tr>
 
 
 <td class="flipper">
 <ul class="leftside">
 
 <li><a href="/p/openxvario/source/browse/branches/openxsensor/oxs_config.h?r=204" title="Previous">&lsaquo;r204</a></li>
 
 </ul>
 </td>
 
 <td class="flipper"><b>r220</b></td>
 
 </tr></table>
 </td> 
 </tr>
</table>

<div class="fc">
 
 
 
<style type="text/css">
.undermouse span {
 background-image: url(https://ssl.gstatic.com/codesite/ph/images/comments.gif); }
</style>
<table class="opened" id="review_comment_area"
><tr>
<td id="nums">
<pre><table width="100%"><tr class="nocursor"><td></td></tr></table></pre>
<pre><table width="100%" id="nums_table_0"><tr id="gr_svn220_1"

><td id="1"><a href="#1">1</a></td></tr
><tr id="gr_svn220_2"

><td id="2"><a href="#2">2</a></td></tr
><tr id="gr_svn220_3"

><td id="3"><a href="#3">3</a></td></tr
><tr id="gr_svn220_4"

><td id="4"><a href="#4">4</a></td></tr
><tr id="gr_svn220_5"

><td id="5"><a href="#5">5</a></td></tr
><tr id="gr_svn220_6"

><td id="6"><a href="#6">6</a></td></tr
><tr id="gr_svn220_7"

><td id="7"><a href="#7">7</a></td></tr
><tr id="gr_svn220_8"

><td id="8"><a href="#8">8</a></td></tr
><tr id="gr_svn220_9"

><td id="9"><a href="#9">9</a></td></tr
><tr id="gr_svn220_10"

><td id="10"><a href="#10">10</a></td></tr
><tr id="gr_svn220_11"

><td id="11"><a href="#11">11</a></td></tr
><tr id="gr_svn220_12"

><td id="12"><a href="#12">12</a></td></tr
><tr id="gr_svn220_13"

><td id="13"><a href="#13">13</a></td></tr
><tr id="gr_svn220_14"

><td id="14"><a href="#14">14</a></td></tr
><tr id="gr_svn220_15"

><td id="15"><a href="#15">15</a></td></tr
><tr id="gr_svn220_16"

><td id="16"><a href="#16">16</a></td></tr
><tr id="gr_svn220_17"

><td id="17"><a href="#17">17</a></td></tr
><tr id="gr_svn220_18"

><td id="18"><a href="#18">18</a></td></tr
><tr id="gr_svn220_19"

><td id="19"><a href="#19">19</a></td></tr
><tr id="gr_svn220_20"

><td id="20"><a href="#20">20</a></td></tr
><tr id="gr_svn220_21"

><td id="21"><a href="#21">21</a></td></tr
><tr id="gr_svn220_22"

><td id="22"><a href="#22">22</a></td></tr
><tr id="gr_svn220_23"

><td id="23"><a href="#23">23</a></td></tr
><tr id="gr_svn220_24"

><td id="24"><a href="#24">24</a></td></tr
><tr id="gr_svn220_25"

><td id="25"><a href="#25">25</a></td></tr
><tr id="gr_svn220_26"

><td id="26"><a href="#26">26</a></td></tr
><tr id="gr_svn220_27"

><td id="27"><a href="#27">27</a></td></tr
><tr id="gr_svn220_28"

><td id="28"><a href="#28">28</a></td></tr
><tr id="gr_svn220_29"

><td id="29"><a href="#29">29</a></td></tr
><tr id="gr_svn220_30"

><td id="30"><a href="#30">30</a></td></tr
><tr id="gr_svn220_31"

><td id="31"><a href="#31">31</a></td></tr
><tr id="gr_svn220_32"

><td id="32"><a href="#32">32</a></td></tr
><tr id="gr_svn220_33"

><td id="33"><a href="#33">33</a></td></tr
><tr id="gr_svn220_34"

><td id="34"><a href="#34">34</a></td></tr
><tr id="gr_svn220_35"

><td id="35"><a href="#35">35</a></td></tr
><tr id="gr_svn220_36"

><td id="36"><a href="#36">36</a></td></tr
><tr id="gr_svn220_37"

><td id="37"><a href="#37">37</a></td></tr
><tr id="gr_svn220_38"

><td id="38"><a href="#38">38</a></td></tr
><tr id="gr_svn220_39"

><td id="39"><a href="#39">39</a></td></tr
><tr id="gr_svn220_40"

><td id="40"><a href="#40">40</a></td></tr
><tr id="gr_svn220_41"

><td id="41"><a href="#41">41</a></td></tr
><tr id="gr_svn220_42"

><td id="42"><a href="#42">42</a></td></tr
><tr id="gr_svn220_43"

><td id="43"><a href="#43">43</a></td></tr
><tr id="gr_svn220_44"

><td id="44"><a href="#44">44</a></td></tr
><tr id="gr_svn220_45"

><td id="45"><a href="#45">45</a></td></tr
><tr id="gr_svn220_46"

><td id="46"><a href="#46">46</a></td></tr
><tr id="gr_svn220_47"

><td id="47"><a href="#47">47</a></td></tr
><tr id="gr_svn220_48"

><td id="48"><a href="#48">48</a></td></tr
><tr id="gr_svn220_49"

><td id="49"><a href="#49">49</a></td></tr
><tr id="gr_svn220_50"

><td id="50"><a href="#50">50</a></td></tr
><tr id="gr_svn220_51"

><td id="51"><a href="#51">51</a></td></tr
><tr id="gr_svn220_52"

><td id="52"><a href="#52">52</a></td></tr
><tr id="gr_svn220_53"

><td id="53"><a href="#53">53</a></td></tr
><tr id="gr_svn220_54"

><td id="54"><a href="#54">54</a></td></tr
><tr id="gr_svn220_55"

><td id="55"><a href="#55">55</a></td></tr
><tr id="gr_svn220_56"

><td id="56"><a href="#56">56</a></td></tr
><tr id="gr_svn220_57"

><td id="57"><a href="#57">57</a></td></tr
><tr id="gr_svn220_58"

><td id="58"><a href="#58">58</a></td></tr
><tr id="gr_svn220_59"

><td id="59"><a href="#59">59</a></td></tr
><tr id="gr_svn220_60"

><td id="60"><a href="#60">60</a></td></tr
><tr id="gr_svn220_61"

><td id="61"><a href="#61">61</a></td></tr
><tr id="gr_svn220_62"

><td id="62"><a href="#62">62</a></td></tr
><tr id="gr_svn220_63"

><td id="63"><a href="#63">63</a></td></tr
><tr id="gr_svn220_64"

><td id="64"><a href="#64">64</a></td></tr
><tr id="gr_svn220_65"

><td id="65"><a href="#65">65</a></td></tr
><tr id="gr_svn220_66"

><td id="66"><a href="#66">66</a></td></tr
><tr id="gr_svn220_67"

><td id="67"><a href="#67">67</a></td></tr
><tr id="gr_svn220_68"

><td id="68"><a href="#68">68</a></td></tr
><tr id="gr_svn220_69"

><td id="69"><a href="#69">69</a></td></tr
><tr id="gr_svn220_70"

><td id="70"><a href="#70">70</a></td></tr
><tr id="gr_svn220_71"

><td id="71"><a href="#71">71</a></td></tr
><tr id="gr_svn220_72"

><td id="72"><a href="#72">72</a></td></tr
><tr id="gr_svn220_73"

><td id="73"><a href="#73">73</a></td></tr
><tr id="gr_svn220_74"

><td id="74"><a href="#74">74</a></td></tr
><tr id="gr_svn220_75"

><td id="75"><a href="#75">75</a></td></tr
><tr id="gr_svn220_76"

><td id="76"><a href="#76">76</a></td></tr
><tr id="gr_svn220_77"

><td id="77"><a href="#77">77</a></td></tr
><tr id="gr_svn220_78"

><td id="78"><a href="#78">78</a></td></tr
><tr id="gr_svn220_79"

><td id="79"><a href="#79">79</a></td></tr
><tr id="gr_svn220_80"

><td id="80"><a href="#80">80</a></td></tr
><tr id="gr_svn220_81"

><td id="81"><a href="#81">81</a></td></tr
><tr id="gr_svn220_82"

><td id="82"><a href="#82">82</a></td></tr
><tr id="gr_svn220_83"

><td id="83"><a href="#83">83</a></td></tr
><tr id="gr_svn220_84"

><td id="84"><a href="#84">84</a></td></tr
><tr id="gr_svn220_85"

><td id="85"><a href="#85">85</a></td></tr
><tr id="gr_svn220_86"

><td id="86"><a href="#86">86</a></td></tr
><tr id="gr_svn220_87"

><td id="87"><a href="#87">87</a></td></tr
><tr id="gr_svn220_88"

><td id="88"><a href="#88">88</a></td></tr
><tr id="gr_svn220_89"

><td id="89"><a href="#89">89</a></td></tr
><tr id="gr_svn220_90"

><td id="90"><a href="#90">90</a></td></tr
><tr id="gr_svn220_91"

><td id="91"><a href="#91">91</a></td></tr
><tr id="gr_svn220_92"

><td id="92"><a href="#92">92</a></td></tr
><tr id="gr_svn220_93"

><td id="93"><a href="#93">93</a></td></tr
><tr id="gr_svn220_94"

><td id="94"><a href="#94">94</a></td></tr
><tr id="gr_svn220_95"

><td id="95"><a href="#95">95</a></td></tr
><tr id="gr_svn220_96"

><td id="96"><a href="#96">96</a></td></tr
><tr id="gr_svn220_97"

><td id="97"><a href="#97">97</a></td></tr
><tr id="gr_svn220_98"

><td id="98"><a href="#98">98</a></td></tr
><tr id="gr_svn220_99"

><td id="99"><a href="#99">99</a></td></tr
><tr id="gr_svn220_100"

><td id="100"><a href="#100">100</a></td></tr
><tr id="gr_svn220_101"

><td id="101"><a href="#101">101</a></td></tr
><tr id="gr_svn220_102"

><td id="102"><a href="#102">102</a></td></tr
><tr id="gr_svn220_103"

><td id="103"><a href="#103">103</a></td></tr
><tr id="gr_svn220_104"

><td id="104"><a href="#104">104</a></td></tr
><tr id="gr_svn220_105"

><td id="105"><a href="#105">105</a></td></tr
><tr id="gr_svn220_106"

><td id="106"><a href="#106">106</a></td></tr
><tr id="gr_svn220_107"

><td id="107"><a href="#107">107</a></td></tr
><tr id="gr_svn220_108"

><td id="108"><a href="#108">108</a></td></tr
><tr id="gr_svn220_109"

><td id="109"><a href="#109">109</a></td></tr
><tr id="gr_svn220_110"

><td id="110"><a href="#110">110</a></td></tr
><tr id="gr_svn220_111"

><td id="111"><a href="#111">111</a></td></tr
><tr id="gr_svn220_112"

><td id="112"><a href="#112">112</a></td></tr
><tr id="gr_svn220_113"

><td id="113"><a href="#113">113</a></td></tr
><tr id="gr_svn220_114"

><td id="114"><a href="#114">114</a></td></tr
><tr id="gr_svn220_115"

><td id="115"><a href="#115">115</a></td></tr
><tr id="gr_svn220_116"

><td id="116"><a href="#116">116</a></td></tr
><tr id="gr_svn220_117"

><td id="117"><a href="#117">117</a></td></tr
><tr id="gr_svn220_118"

><td id="118"><a href="#118">118</a></td></tr
><tr id="gr_svn220_119"

><td id="119"><a href="#119">119</a></td></tr
><tr id="gr_svn220_120"

><td id="120"><a href="#120">120</a></td></tr
><tr id="gr_svn220_121"

><td id="121"><a href="#121">121</a></td></tr
><tr id="gr_svn220_122"

><td id="122"><a href="#122">122</a></td></tr
><tr id="gr_svn220_123"

><td id="123"><a href="#123">123</a></td></tr
><tr id="gr_svn220_124"

><td id="124"><a href="#124">124</a></td></tr
><tr id="gr_svn220_125"

><td id="125"><a href="#125">125</a></td></tr
><tr id="gr_svn220_126"

><td id="126"><a href="#126">126</a></td></tr
><tr id="gr_svn220_127"

><td id="127"><a href="#127">127</a></td></tr
><tr id="gr_svn220_128"

><td id="128"><a href="#128">128</a></td></tr
><tr id="gr_svn220_129"

><td id="129"><a href="#129">129</a></td></tr
><tr id="gr_svn220_130"

><td id="130"><a href="#130">130</a></td></tr
><tr id="gr_svn220_131"

><td id="131"><a href="#131">131</a></td></tr
><tr id="gr_svn220_132"

><td id="132"><a href="#132">132</a></td></tr
><tr id="gr_svn220_133"

><td id="133"><a href="#133">133</a></td></tr
><tr id="gr_svn220_134"

><td id="134"><a href="#134">134</a></td></tr
><tr id="gr_svn220_135"

><td id="135"><a href="#135">135</a></td></tr
><tr id="gr_svn220_136"

><td id="136"><a href="#136">136</a></td></tr
><tr id="gr_svn220_137"

><td id="137"><a href="#137">137</a></td></tr
><tr id="gr_svn220_138"

><td id="138"><a href="#138">138</a></td></tr
><tr id="gr_svn220_139"

><td id="139"><a href="#139">139</a></td></tr
><tr id="gr_svn220_140"

><td id="140"><a href="#140">140</a></td></tr
><tr id="gr_svn220_141"

><td id="141"><a href="#141">141</a></td></tr
><tr id="gr_svn220_142"

><td id="142"><a href="#142">142</a></td></tr
><tr id="gr_svn220_143"

><td id="143"><a href="#143">143</a></td></tr
><tr id="gr_svn220_144"

><td id="144"><a href="#144">144</a></td></tr
><tr id="gr_svn220_145"

><td id="145"><a href="#145">145</a></td></tr
><tr id="gr_svn220_146"

><td id="146"><a href="#146">146</a></td></tr
><tr id="gr_svn220_147"

><td id="147"><a href="#147">147</a></td></tr
><tr id="gr_svn220_148"

><td id="148"><a href="#148">148</a></td></tr
><tr id="gr_svn220_149"

><td id="149"><a href="#149">149</a></td></tr
><tr id="gr_svn220_150"

><td id="150"><a href="#150">150</a></td></tr
><tr id="gr_svn220_151"

><td id="151"><a href="#151">151</a></td></tr
><tr id="gr_svn220_152"

><td id="152"><a href="#152">152</a></td></tr
><tr id="gr_svn220_153"

><td id="153"><a href="#153">153</a></td></tr
><tr id="gr_svn220_154"

><td id="154"><a href="#154">154</a></td></tr
><tr id="gr_svn220_155"

><td id="155"><a href="#155">155</a></td></tr
><tr id="gr_svn220_156"

><td id="156"><a href="#156">156</a></td></tr
><tr id="gr_svn220_157"

><td id="157"><a href="#157">157</a></td></tr
><tr id="gr_svn220_158"

><td id="158"><a href="#158">158</a></td></tr
><tr id="gr_svn220_159"

><td id="159"><a href="#159">159</a></td></tr
><tr id="gr_svn220_160"

><td id="160"><a href="#160">160</a></td></tr
><tr id="gr_svn220_161"

><td id="161"><a href="#161">161</a></td></tr
><tr id="gr_svn220_162"

><td id="162"><a href="#162">162</a></td></tr
><tr id="gr_svn220_163"

><td id="163"><a href="#163">163</a></td></tr
><tr id="gr_svn220_164"

><td id="164"><a href="#164">164</a></td></tr
><tr id="gr_svn220_165"

><td id="165"><a href="#165">165</a></td></tr
><tr id="gr_svn220_166"

><td id="166"><a href="#166">166</a></td></tr
><tr id="gr_svn220_167"

><td id="167"><a href="#167">167</a></td></tr
><tr id="gr_svn220_168"

><td id="168"><a href="#168">168</a></td></tr
><tr id="gr_svn220_169"

><td id="169"><a href="#169">169</a></td></tr
><tr id="gr_svn220_170"

><td id="170"><a href="#170">170</a></td></tr
><tr id="gr_svn220_171"

><td id="171"><a href="#171">171</a></td></tr
><tr id="gr_svn220_172"

><td id="172"><a href="#172">172</a></td></tr
><tr id="gr_svn220_173"

><td id="173"><a href="#173">173</a></td></tr
><tr id="gr_svn220_174"

><td id="174"><a href="#174">174</a></td></tr
><tr id="gr_svn220_175"

><td id="175"><a href="#175">175</a></td></tr
><tr id="gr_svn220_176"

><td id="176"><a href="#176">176</a></td></tr
><tr id="gr_svn220_177"

><td id="177"><a href="#177">177</a></td></tr
><tr id="gr_svn220_178"

><td id="178"><a href="#178">178</a></td></tr
><tr id="gr_svn220_179"

><td id="179"><a href="#179">179</a></td></tr
><tr id="gr_svn220_180"

><td id="180"><a href="#180">180</a></td></tr
><tr id="gr_svn220_181"

><td id="181"><a href="#181">181</a></td></tr
><tr id="gr_svn220_182"

><td id="182"><a href="#182">182</a></td></tr
><tr id="gr_svn220_183"

><td id="183"><a href="#183">183</a></td></tr
><tr id="gr_svn220_184"

><td id="184"><a href="#184">184</a></td></tr
><tr id="gr_svn220_185"

><td id="185"><a href="#185">185</a></td></tr
><tr id="gr_svn220_186"

><td id="186"><a href="#186">186</a></td></tr
><tr id="gr_svn220_187"

><td id="187"><a href="#187">187</a></td></tr
><tr id="gr_svn220_188"

><td id="188"><a href="#188">188</a></td></tr
><tr id="gr_svn220_189"

><td id="189"><a href="#189">189</a></td></tr
><tr id="gr_svn220_190"

><td id="190"><a href="#190">190</a></td></tr
><tr id="gr_svn220_191"

><td id="191"><a href="#191">191</a></td></tr
><tr id="gr_svn220_192"

><td id="192"><a href="#192">192</a></td></tr
><tr id="gr_svn220_193"

><td id="193"><a href="#193">193</a></td></tr
><tr id="gr_svn220_194"

><td id="194"><a href="#194">194</a></td></tr
><tr id="gr_svn220_195"

><td id="195"><a href="#195">195</a></td></tr
><tr id="gr_svn220_196"

><td id="196"><a href="#196">196</a></td></tr
><tr id="gr_svn220_197"

><td id="197"><a href="#197">197</a></td></tr
><tr id="gr_svn220_198"

><td id="198"><a href="#198">198</a></td></tr
><tr id="gr_svn220_199"

><td id="199"><a href="#199">199</a></td></tr
><tr id="gr_svn220_200"

><td id="200"><a href="#200">200</a></td></tr
><tr id="gr_svn220_201"

><td id="201"><a href="#201">201</a></td></tr
><tr id="gr_svn220_202"

><td id="202"><a href="#202">202</a></td></tr
><tr id="gr_svn220_203"

><td id="203"><a href="#203">203</a></td></tr
><tr id="gr_svn220_204"

><td id="204"><a href="#204">204</a></td></tr
><tr id="gr_svn220_205"

><td id="205"><a href="#205">205</a></td></tr
><tr id="gr_svn220_206"

><td id="206"><a href="#206">206</a></td></tr
><tr id="gr_svn220_207"

><td id="207"><a href="#207">207</a></td></tr
><tr id="gr_svn220_208"

><td id="208"><a href="#208">208</a></td></tr
><tr id="gr_svn220_209"

><td id="209"><a href="#209">209</a></td></tr
><tr id="gr_svn220_210"

><td id="210"><a href="#210">210</a></td></tr
><tr id="gr_svn220_211"

><td id="211"><a href="#211">211</a></td></tr
><tr id="gr_svn220_212"

><td id="212"><a href="#212">212</a></td></tr
><tr id="gr_svn220_213"

><td id="213"><a href="#213">213</a></td></tr
><tr id="gr_svn220_214"

><td id="214"><a href="#214">214</a></td></tr
><tr id="gr_svn220_215"

><td id="215"><a href="#215">215</a></td></tr
><tr id="gr_svn220_216"

><td id="216"><a href="#216">216</a></td></tr
><tr id="gr_svn220_217"

><td id="217"><a href="#217">217</a></td></tr
><tr id="gr_svn220_218"

><td id="218"><a href="#218">218</a></td></tr
><tr id="gr_svn220_219"

><td id="219"><a href="#219">219</a></td></tr
><tr id="gr_svn220_220"

><td id="220"><a href="#220">220</a></td></tr
><tr id="gr_svn220_221"

><td id="221"><a href="#221">221</a></td></tr
><tr id="gr_svn220_222"

><td id="222"><a href="#222">222</a></td></tr
><tr id="gr_svn220_223"

><td id="223"><a href="#223">223</a></td></tr
><tr id="gr_svn220_224"

><td id="224"><a href="#224">224</a></td></tr
><tr id="gr_svn220_225"

><td id="225"><a href="#225">225</a></td></tr
><tr id="gr_svn220_226"

><td id="226"><a href="#226">226</a></td></tr
><tr id="gr_svn220_227"

><td id="227"><a href="#227">227</a></td></tr
><tr id="gr_svn220_228"

><td id="228"><a href="#228">228</a></td></tr
><tr id="gr_svn220_229"

><td id="229"><a href="#229">229</a></td></tr
><tr id="gr_svn220_230"

><td id="230"><a href="#230">230</a></td></tr
><tr id="gr_svn220_231"

><td id="231"><a href="#231">231</a></td></tr
><tr id="gr_svn220_232"

><td id="232"><a href="#232">232</a></td></tr
><tr id="gr_svn220_233"

><td id="233"><a href="#233">233</a></td></tr
><tr id="gr_svn220_234"

><td id="234"><a href="#234">234</a></td></tr
><tr id="gr_svn220_235"

><td id="235"><a href="#235">235</a></td></tr
><tr id="gr_svn220_236"

><td id="236"><a href="#236">236</a></td></tr
><tr id="gr_svn220_237"

><td id="237"><a href="#237">237</a></td></tr
><tr id="gr_svn220_238"

><td id="238"><a href="#238">238</a></td></tr
><tr id="gr_svn220_239"

><td id="239"><a href="#239">239</a></td></tr
><tr id="gr_svn220_240"

><td id="240"><a href="#240">240</a></td></tr
><tr id="gr_svn220_241"

><td id="241"><a href="#241">241</a></td></tr
><tr id="gr_svn220_242"

><td id="242"><a href="#242">242</a></td></tr
><tr id="gr_svn220_243"

><td id="243"><a href="#243">243</a></td></tr
><tr id="gr_svn220_244"

><td id="244"><a href="#244">244</a></td></tr
><tr id="gr_svn220_245"

><td id="245"><a href="#245">245</a></td></tr
><tr id="gr_svn220_246"

><td id="246"><a href="#246">246</a></td></tr
><tr id="gr_svn220_247"

><td id="247"><a href="#247">247</a></td></tr
><tr id="gr_svn220_248"

><td id="248"><a href="#248">248</a></td></tr
><tr id="gr_svn220_249"

><td id="249"><a href="#249">249</a></td></tr
><tr id="gr_svn220_250"

><td id="250"><a href="#250">250</a></td></tr
><tr id="gr_svn220_251"

><td id="251"><a href="#251">251</a></td></tr
><tr id="gr_svn220_252"

><td id="252"><a href="#252">252</a></td></tr
><tr id="gr_svn220_253"

><td id="253"><a href="#253">253</a></td></tr
><tr id="gr_svn220_254"

><td id="254"><a href="#254">254</a></td></tr
><tr id="gr_svn220_255"

><td id="255"><a href="#255">255</a></td></tr
><tr id="gr_svn220_256"

><td id="256"><a href="#256">256</a></td></tr
><tr id="gr_svn220_257"

><td id="257"><a href="#257">257</a></td></tr
><tr id="gr_svn220_258"

><td id="258"><a href="#258">258</a></td></tr
><tr id="gr_svn220_259"

><td id="259"><a href="#259">259</a></td></tr
><tr id="gr_svn220_260"

><td id="260"><a href="#260">260</a></td></tr
><tr id="gr_svn220_261"

><td id="261"><a href="#261">261</a></td></tr
><tr id="gr_svn220_262"

><td id="262"><a href="#262">262</a></td></tr
><tr id="gr_svn220_263"

><td id="263"><a href="#263">263</a></td></tr
><tr id="gr_svn220_264"

><td id="264"><a href="#264">264</a></td></tr
><tr id="gr_svn220_265"

><td id="265"><a href="#265">265</a></td></tr
><tr id="gr_svn220_266"

><td id="266"><a href="#266">266</a></td></tr
><tr id="gr_svn220_267"

><td id="267"><a href="#267">267</a></td></tr
><tr id="gr_svn220_268"

><td id="268"><a href="#268">268</a></td></tr
><tr id="gr_svn220_269"

><td id="269"><a href="#269">269</a></td></tr
><tr id="gr_svn220_270"

><td id="270"><a href="#270">270</a></td></tr
><tr id="gr_svn220_271"

><td id="271"><a href="#271">271</a></td></tr
><tr id="gr_svn220_272"

><td id="272"><a href="#272">272</a></td></tr
><tr id="gr_svn220_273"

><td id="273"><a href="#273">273</a></td></tr
><tr id="gr_svn220_274"

><td id="274"><a href="#274">274</a></td></tr
><tr id="gr_svn220_275"

><td id="275"><a href="#275">275</a></td></tr
><tr id="gr_svn220_276"

><td id="276"><a href="#276">276</a></td></tr
><tr id="gr_svn220_277"

><td id="277"><a href="#277">277</a></td></tr
><tr id="gr_svn220_278"

><td id="278"><a href="#278">278</a></td></tr
><tr id="gr_svn220_279"

><td id="279"><a href="#279">279</a></td></tr
><tr id="gr_svn220_280"

><td id="280"><a href="#280">280</a></td></tr
><tr id="gr_svn220_281"

><td id="281"><a href="#281">281</a></td></tr
><tr id="gr_svn220_282"

><td id="282"><a href="#282">282</a></td></tr
><tr id="gr_svn220_283"

><td id="283"><a href="#283">283</a></td></tr
><tr id="gr_svn220_284"

><td id="284"><a href="#284">284</a></td></tr
><tr id="gr_svn220_285"

><td id="285"><a href="#285">285</a></td></tr
><tr id="gr_svn220_286"

><td id="286"><a href="#286">286</a></td></tr
><tr id="gr_svn220_287"

><td id="287"><a href="#287">287</a></td></tr
><tr id="gr_svn220_288"

><td id="288"><a href="#288">288</a></td></tr
><tr id="gr_svn220_289"

><td id="289"><a href="#289">289</a></td></tr
><tr id="gr_svn220_290"

><td id="290"><a href="#290">290</a></td></tr
><tr id="gr_svn220_291"

><td id="291"><a href="#291">291</a></td></tr
><tr id="gr_svn220_292"

><td id="292"><a href="#292">292</a></td></tr
><tr id="gr_svn220_293"

><td id="293"><a href="#293">293</a></td></tr
><tr id="gr_svn220_294"

><td id="294"><a href="#294">294</a></td></tr
><tr id="gr_svn220_295"

><td id="295"><a href="#295">295</a></td></tr
><tr id="gr_svn220_296"

><td id="296"><a href="#296">296</a></td></tr
><tr id="gr_svn220_297"

><td id="297"><a href="#297">297</a></td></tr
><tr id="gr_svn220_298"

><td id="298"><a href="#298">298</a></td></tr
><tr id="gr_svn220_299"

><td id="299"><a href="#299">299</a></td></tr
><tr id="gr_svn220_300"

><td id="300"><a href="#300">300</a></td></tr
><tr id="gr_svn220_301"

><td id="301"><a href="#301">301</a></td></tr
><tr id="gr_svn220_302"

><td id="302"><a href="#302">302</a></td></tr
><tr id="gr_svn220_303"

><td id="303"><a href="#303">303</a></td></tr
><tr id="gr_svn220_304"

><td id="304"><a href="#304">304</a></td></tr
><tr id="gr_svn220_305"

><td id="305"><a href="#305">305</a></td></tr
><tr id="gr_svn220_306"

><td id="306"><a href="#306">306</a></td></tr
><tr id="gr_svn220_307"

><td id="307"><a href="#307">307</a></td></tr
><tr id="gr_svn220_308"

><td id="308"><a href="#308">308</a></td></tr
><tr id="gr_svn220_309"

><td id="309"><a href="#309">309</a></td></tr
><tr id="gr_svn220_310"

><td id="310"><a href="#310">310</a></td></tr
><tr id="gr_svn220_311"

><td id="311"><a href="#311">311</a></td></tr
><tr id="gr_svn220_312"

><td id="312"><a href="#312">312</a></td></tr
><tr id="gr_svn220_313"

><td id="313"><a href="#313">313</a></td></tr
><tr id="gr_svn220_314"

><td id="314"><a href="#314">314</a></td></tr
><tr id="gr_svn220_315"

><td id="315"><a href="#315">315</a></td></tr
><tr id="gr_svn220_316"

><td id="316"><a href="#316">316</a></td></tr
><tr id="gr_svn220_317"

><td id="317"><a href="#317">317</a></td></tr
><tr id="gr_svn220_318"

><td id="318"><a href="#318">318</a></td></tr
><tr id="gr_svn220_319"

><td id="319"><a href="#319">319</a></td></tr
><tr id="gr_svn220_320"

><td id="320"><a href="#320">320</a></td></tr
><tr id="gr_svn220_321"

><td id="321"><a href="#321">321</a></td></tr
><tr id="gr_svn220_322"

><td id="322"><a href="#322">322</a></td></tr
><tr id="gr_svn220_323"

><td id="323"><a href="#323">323</a></td></tr
><tr id="gr_svn220_324"

><td id="324"><a href="#324">324</a></td></tr
><tr id="gr_svn220_325"

><td id="325"><a href="#325">325</a></td></tr
><tr id="gr_svn220_326"

><td id="326"><a href="#326">326</a></td></tr
><tr id="gr_svn220_327"

><td id="327"><a href="#327">327</a></td></tr
><tr id="gr_svn220_328"

><td id="328"><a href="#328">328</a></td></tr
><tr id="gr_svn220_329"

><td id="329"><a href="#329">329</a></td></tr
><tr id="gr_svn220_330"

><td id="330"><a href="#330">330</a></td></tr
><tr id="gr_svn220_331"

><td id="331"><a href="#331">331</a></td></tr
><tr id="gr_svn220_332"

><td id="332"><a href="#332">332</a></td></tr
><tr id="gr_svn220_333"

><td id="333"><a href="#333">333</a></td></tr
><tr id="gr_svn220_334"

><td id="334"><a href="#334">334</a></td></tr
><tr id="gr_svn220_335"

><td id="335"><a href="#335">335</a></td></tr
><tr id="gr_svn220_336"

><td id="336"><a href="#336">336</a></td></tr
><tr id="gr_svn220_337"

><td id="337"><a href="#337">337</a></td></tr
><tr id="gr_svn220_338"

><td id="338"><a href="#338">338</a></td></tr
><tr id="gr_svn220_339"

><td id="339"><a href="#339">339</a></td></tr
><tr id="gr_svn220_340"

><td id="340"><a href="#340">340</a></td></tr
><tr id="gr_svn220_341"

><td id="341"><a href="#341">341</a></td></tr
><tr id="gr_svn220_342"

><td id="342"><a href="#342">342</a></td></tr
><tr id="gr_svn220_343"

><td id="343"><a href="#343">343</a></td></tr
><tr id="gr_svn220_344"

><td id="344"><a href="#344">344</a></td></tr
><tr id="gr_svn220_345"

><td id="345"><a href="#345">345</a></td></tr
><tr id="gr_svn220_346"

><td id="346"><a href="#346">346</a></td></tr
><tr id="gr_svn220_347"

><td id="347"><a href="#347">347</a></td></tr
><tr id="gr_svn220_348"

><td id="348"><a href="#348">348</a></td></tr
><tr id="gr_svn220_349"

><td id="349"><a href="#349">349</a></td></tr
><tr id="gr_svn220_350"

><td id="350"><a href="#350">350</a></td></tr
><tr id="gr_svn220_351"

><td id="351"><a href="#351">351</a></td></tr
><tr id="gr_svn220_352"

><td id="352"><a href="#352">352</a></td></tr
><tr id="gr_svn220_353"

><td id="353"><a href="#353">353</a></td></tr
><tr id="gr_svn220_354"

><td id="354"><a href="#354">354</a></td></tr
><tr id="gr_svn220_355"

><td id="355"><a href="#355">355</a></td></tr
><tr id="gr_svn220_356"

><td id="356"><a href="#356">356</a></td></tr
><tr id="gr_svn220_357"

><td id="357"><a href="#357">357</a></td></tr
><tr id="gr_svn220_358"

><td id="358"><a href="#358">358</a></td></tr
><tr id="gr_svn220_359"

><td id="359"><a href="#359">359</a></td></tr
><tr id="gr_svn220_360"

><td id="360"><a href="#360">360</a></td></tr
><tr id="gr_svn220_361"

><td id="361"><a href="#361">361</a></td></tr
><tr id="gr_svn220_362"

><td id="362"><a href="#362">362</a></td></tr
><tr id="gr_svn220_363"

><td id="363"><a href="#363">363</a></td></tr
><tr id="gr_svn220_364"

><td id="364"><a href="#364">364</a></td></tr
><tr id="gr_svn220_365"

><td id="365"><a href="#365">365</a></td></tr
><tr id="gr_svn220_366"

><td id="366"><a href="#366">366</a></td></tr
><tr id="gr_svn220_367"

><td id="367"><a href="#367">367</a></td></tr
><tr id="gr_svn220_368"

><td id="368"><a href="#368">368</a></td></tr
><tr id="gr_svn220_369"

><td id="369"><a href="#369">369</a></td></tr
><tr id="gr_svn220_370"

><td id="370"><a href="#370">370</a></td></tr
><tr id="gr_svn220_371"

><td id="371"><a href="#371">371</a></td></tr
><tr id="gr_svn220_372"

><td id="372"><a href="#372">372</a></td></tr
><tr id="gr_svn220_373"

><td id="373"><a href="#373">373</a></td></tr
><tr id="gr_svn220_374"

><td id="374"><a href="#374">374</a></td></tr
><tr id="gr_svn220_375"

><td id="375"><a href="#375">375</a></td></tr
><tr id="gr_svn220_376"

><td id="376"><a href="#376">376</a></td></tr
><tr id="gr_svn220_377"

><td id="377"><a href="#377">377</a></td></tr
><tr id="gr_svn220_378"

><td id="378"><a href="#378">378</a></td></tr
><tr id="gr_svn220_379"

><td id="379"><a href="#379">379</a></td></tr
><tr id="gr_svn220_380"

><td id="380"><a href="#380">380</a></td></tr
><tr id="gr_svn220_381"

><td id="381"><a href="#381">381</a></td></tr
><tr id="gr_svn220_382"

><td id="382"><a href="#382">382</a></td></tr
><tr id="gr_svn220_383"

><td id="383"><a href="#383">383</a></td></tr
><tr id="gr_svn220_384"

><td id="384"><a href="#384">384</a></td></tr
><tr id="gr_svn220_385"

><td id="385"><a href="#385">385</a></td></tr
><tr id="gr_svn220_386"

><td id="386"><a href="#386">386</a></td></tr
><tr id="gr_svn220_387"

><td id="387"><a href="#387">387</a></td></tr
><tr id="gr_svn220_388"

><td id="388"><a href="#388">388</a></td></tr
><tr id="gr_svn220_389"

><td id="389"><a href="#389">389</a></td></tr
><tr id="gr_svn220_390"

><td id="390"><a href="#390">390</a></td></tr
><tr id="gr_svn220_391"

><td id="391"><a href="#391">391</a></td></tr
><tr id="gr_svn220_392"

><td id="392"><a href="#392">392</a></td></tr
><tr id="gr_svn220_393"

><td id="393"><a href="#393">393</a></td></tr
><tr id="gr_svn220_394"

><td id="394"><a href="#394">394</a></td></tr
><tr id="gr_svn220_395"

><td id="395"><a href="#395">395</a></td></tr
><tr id="gr_svn220_396"

><td id="396"><a href="#396">396</a></td></tr
><tr id="gr_svn220_397"

><td id="397"><a href="#397">397</a></td></tr
><tr id="gr_svn220_398"

><td id="398"><a href="#398">398</a></td></tr
><tr id="gr_svn220_399"

><td id="399"><a href="#399">399</a></td></tr
><tr id="gr_svn220_400"

><td id="400"><a href="#400">400</a></td></tr
><tr id="gr_svn220_401"

><td id="401"><a href="#401">401</a></td></tr
><tr id="gr_svn220_402"

><td id="402"><a href="#402">402</a></td></tr
><tr id="gr_svn220_403"

><td id="403"><a href="#403">403</a></td></tr
><tr id="gr_svn220_404"

><td id="404"><a href="#404">404</a></td></tr
><tr id="gr_svn220_405"

><td id="405"><a href="#405">405</a></td></tr
><tr id="gr_svn220_406"

><td id="406"><a href="#406">406</a></td></tr
><tr id="gr_svn220_407"

><td id="407"><a href="#407">407</a></td></tr
><tr id="gr_svn220_408"

><td id="408"><a href="#408">408</a></td></tr
><tr id="gr_svn220_409"

><td id="409"><a href="#409">409</a></td></tr
><tr id="gr_svn220_410"

><td id="410"><a href="#410">410</a></td></tr
><tr id="gr_svn220_411"

><td id="411"><a href="#411">411</a></td></tr
><tr id="gr_svn220_412"

><td id="412"><a href="#412">412</a></td></tr
><tr id="gr_svn220_413"

><td id="413"><a href="#413">413</a></td></tr
><tr id="gr_svn220_414"

><td id="414"><a href="#414">414</a></td></tr
><tr id="gr_svn220_415"

><td id="415"><a href="#415">415</a></td></tr
><tr id="gr_svn220_416"

><td id="416"><a href="#416">416</a></td></tr
><tr id="gr_svn220_417"

><td id="417"><a href="#417">417</a></td></tr
><tr id="gr_svn220_418"

><td id="418"><a href="#418">418</a></td></tr
><tr id="gr_svn220_419"

><td id="419"><a href="#419">419</a></td></tr
><tr id="gr_svn220_420"

><td id="420"><a href="#420">420</a></td></tr
><tr id="gr_svn220_421"

><td id="421"><a href="#421">421</a></td></tr
><tr id="gr_svn220_422"

><td id="422"><a href="#422">422</a></td></tr
><tr id="gr_svn220_423"

><td id="423"><a href="#423">423</a></td></tr
><tr id="gr_svn220_424"

><td id="424"><a href="#424">424</a></td></tr
><tr id="gr_svn220_425"

><td id="425"><a href="#425">425</a></td></tr
><tr id="gr_svn220_426"

><td id="426"><a href="#426">426</a></td></tr
><tr id="gr_svn220_427"

><td id="427"><a href="#427">427</a></td></tr
><tr id="gr_svn220_428"

><td id="428"><a href="#428">428</a></td></tr
><tr id="gr_svn220_429"

><td id="429"><a href="#429">429</a></td></tr
><tr id="gr_svn220_430"

><td id="430"><a href="#430">430</a></td></tr
><tr id="gr_svn220_431"

><td id="431"><a href="#431">431</a></td></tr
><tr id="gr_svn220_432"

><td id="432"><a href="#432">432</a></td></tr
><tr id="gr_svn220_433"

><td id="433"><a href="#433">433</a></td></tr
><tr id="gr_svn220_434"

><td id="434"><a href="#434">434</a></td></tr
><tr id="gr_svn220_435"

><td id="435"><a href="#435">435</a></td></tr
><tr id="gr_svn220_436"

><td id="436"><a href="#436">436</a></td></tr
><tr id="gr_svn220_437"

><td id="437"><a href="#437">437</a></td></tr
><tr id="gr_svn220_438"

><td id="438"><a href="#438">438</a></td></tr
><tr id="gr_svn220_439"

><td id="439"><a href="#439">439</a></td></tr
><tr id="gr_svn220_440"

><td id="440"><a href="#440">440</a></td></tr
><tr id="gr_svn220_441"

><td id="441"><a href="#441">441</a></td></tr
><tr id="gr_svn220_442"

><td id="442"><a href="#442">442</a></td></tr
><tr id="gr_svn220_443"

><td id="443"><a href="#443">443</a></td></tr
><tr id="gr_svn220_444"

><td id="444"><a href="#444">444</a></td></tr
><tr id="gr_svn220_445"

><td id="445"><a href="#445">445</a></td></tr
><tr id="gr_svn220_446"

><td id="446"><a href="#446">446</a></td></tr
><tr id="gr_svn220_447"

><td id="447"><a href="#447">447</a></td></tr
><tr id="gr_svn220_448"

><td id="448"><a href="#448">448</a></td></tr
><tr id="gr_svn220_449"

><td id="449"><a href="#449">449</a></td></tr
><tr id="gr_svn220_450"

><td id="450"><a href="#450">450</a></td></tr
><tr id="gr_svn220_451"

><td id="451"><a href="#451">451</a></td></tr
><tr id="gr_svn220_452"

><td id="452"><a href="#452">452</a></td></tr
><tr id="gr_svn220_453"

><td id="453"><a href="#453">453</a></td></tr
><tr id="gr_svn220_454"

><td id="454"><a href="#454">454</a></td></tr
><tr id="gr_svn220_455"

><td id="455"><a href="#455">455</a></td></tr
><tr id="gr_svn220_456"

><td id="456"><a href="#456">456</a></td></tr
><tr id="gr_svn220_457"

><td id="457"><a href="#457">457</a></td></tr
><tr id="gr_svn220_458"

><td id="458"><a href="#458">458</a></td></tr
><tr id="gr_svn220_459"

><td id="459"><a href="#459">459</a></td></tr
><tr id="gr_svn220_460"

><td id="460"><a href="#460">460</a></td></tr
><tr id="gr_svn220_461"

><td id="461"><a href="#461">461</a></td></tr
><tr id="gr_svn220_462"

><td id="462"><a href="#462">462</a></td></tr
><tr id="gr_svn220_463"

><td id="463"><a href="#463">463</a></td></tr
><tr id="gr_svn220_464"

><td id="464"><a href="#464">464</a></td></tr
><tr id="gr_svn220_465"

><td id="465"><a href="#465">465</a></td></tr
><tr id="gr_svn220_466"

><td id="466"><a href="#466">466</a></td></tr
><tr id="gr_svn220_467"

><td id="467"><a href="#467">467</a></td></tr
><tr id="gr_svn220_468"

><td id="468"><a href="#468">468</a></td></tr
><tr id="gr_svn220_469"

><td id="469"><a href="#469">469</a></td></tr
><tr id="gr_svn220_470"

><td id="470"><a href="#470">470</a></td></tr
><tr id="gr_svn220_471"

><td id="471"><a href="#471">471</a></td></tr
><tr id="gr_svn220_472"

><td id="472"><a href="#472">472</a></td></tr
><tr id="gr_svn220_473"

><td id="473"><a href="#473">473</a></td></tr
><tr id="gr_svn220_474"

><td id="474"><a href="#474">474</a></td></tr
><tr id="gr_svn220_475"

><td id="475"><a href="#475">475</a></td></tr
><tr id="gr_svn220_476"

><td id="476"><a href="#476">476</a></td></tr
><tr id="gr_svn220_477"

><td id="477"><a href="#477">477</a></td></tr
><tr id="gr_svn220_478"

><td id="478"><a href="#478">478</a></td></tr
><tr id="gr_svn220_479"

><td id="479"><a href="#479">479</a></td></tr
><tr id="gr_svn220_480"

><td id="480"><a href="#480">480</a></td></tr
><tr id="gr_svn220_481"

><td id="481"><a href="#481">481</a></td></tr
><tr id="gr_svn220_482"

><td id="482"><a href="#482">482</a></td></tr
><tr id="gr_svn220_483"

><td id="483"><a href="#483">483</a></td></tr
><tr id="gr_svn220_484"

><td id="484"><a href="#484">484</a></td></tr
><tr id="gr_svn220_485"

><td id="485"><a href="#485">485</a></td></tr
><tr id="gr_svn220_486"

><td id="486"><a href="#486">486</a></td></tr
><tr id="gr_svn220_487"

><td id="487"><a href="#487">487</a></td></tr
><tr id="gr_svn220_488"

><td id="488"><a href="#488">488</a></td></tr
><tr id="gr_svn220_489"

><td id="489"><a href="#489">489</a></td></tr
><tr id="gr_svn220_490"

><td id="490"><a href="#490">490</a></td></tr
><tr id="gr_svn220_491"

><td id="491"><a href="#491">491</a></td></tr
><tr id="gr_svn220_492"

><td id="492"><a href="#492">492</a></td></tr
><tr id="gr_svn220_493"

><td id="493"><a href="#493">493</a></td></tr
><tr id="gr_svn220_494"

><td id="494"><a href="#494">494</a></td></tr
><tr id="gr_svn220_495"

><td id="495"><a href="#495">495</a></td></tr
><tr id="gr_svn220_496"

><td id="496"><a href="#496">496</a></td></tr
><tr id="gr_svn220_497"

><td id="497"><a href="#497">497</a></td></tr
><tr id="gr_svn220_498"

><td id="498"><a href="#498">498</a></td></tr
><tr id="gr_svn220_499"

><td id="499"><a href="#499">499</a></td></tr
><tr id="gr_svn220_500"

><td id="500"><a href="#500">500</a></td></tr
><tr id="gr_svn220_501"

><td id="501"><a href="#501">501</a></td></tr
><tr id="gr_svn220_502"

><td id="502"><a href="#502">502</a></td></tr
><tr id="gr_svn220_503"

><td id="503"><a href="#503">503</a></td></tr
><tr id="gr_svn220_504"

><td id="504"><a href="#504">504</a></td></tr
><tr id="gr_svn220_505"

><td id="505"><a href="#505">505</a></td></tr
><tr id="gr_svn220_506"

><td id="506"><a href="#506">506</a></td></tr
><tr id="gr_svn220_507"

><td id="507"><a href="#507">507</a></td></tr
><tr id="gr_svn220_508"

><td id="508"><a href="#508">508</a></td></tr
><tr id="gr_svn220_509"

><td id="509"><a href="#509">509</a></td></tr
><tr id="gr_svn220_510"

><td id="510"><a href="#510">510</a></td></tr
><tr id="gr_svn220_511"

><td id="511"><a href="#511">511</a></td></tr
><tr id="gr_svn220_512"

><td id="512"><a href="#512">512</a></td></tr
><tr id="gr_svn220_513"

><td id="513"><a href="#513">513</a></td></tr
><tr id="gr_svn220_514"

><td id="514"><a href="#514">514</a></td></tr
><tr id="gr_svn220_515"

><td id="515"><a href="#515">515</a></td></tr
><tr id="gr_svn220_516"

><td id="516"><a href="#516">516</a></td></tr
><tr id="gr_svn220_517"

><td id="517"><a href="#517">517</a></td></tr
><tr id="gr_svn220_518"

><td id="518"><a href="#518">518</a></td></tr
><tr id="gr_svn220_519"

><td id="519"><a href="#519">519</a></td></tr
><tr id="gr_svn220_520"

><td id="520"><a href="#520">520</a></td></tr
><tr id="gr_svn220_521"

><td id="521"><a href="#521">521</a></td></tr
><tr id="gr_svn220_522"

><td id="522"><a href="#522">522</a></td></tr
><tr id="gr_svn220_523"

><td id="523"><a href="#523">523</a></td></tr
><tr id="gr_svn220_524"

><td id="524"><a href="#524">524</a></td></tr
><tr id="gr_svn220_525"

><td id="525"><a href="#525">525</a></td></tr
><tr id="gr_svn220_526"

><td id="526"><a href="#526">526</a></td></tr
><tr id="gr_svn220_527"

><td id="527"><a href="#527">527</a></td></tr
><tr id="gr_svn220_528"

><td id="528"><a href="#528">528</a></td></tr
><tr id="gr_svn220_529"

><td id="529"><a href="#529">529</a></td></tr
><tr id="gr_svn220_530"

><td id="530"><a href="#530">530</a></td></tr
><tr id="gr_svn220_531"

><td id="531"><a href="#531">531</a></td></tr
><tr id="gr_svn220_532"

><td id="532"><a href="#532">532</a></td></tr
><tr id="gr_svn220_533"

><td id="533"><a href="#533">533</a></td></tr
><tr id="gr_svn220_534"

><td id="534"><a href="#534">534</a></td></tr
><tr id="gr_svn220_535"

><td id="535"><a href="#535">535</a></td></tr
><tr id="gr_svn220_536"

><td id="536"><a href="#536">536</a></td></tr
><tr id="gr_svn220_537"

><td id="537"><a href="#537">537</a></td></tr
><tr id="gr_svn220_538"

><td id="538"><a href="#538">538</a></td></tr
><tr id="gr_svn220_539"

><td id="539"><a href="#539">539</a></td></tr
><tr id="gr_svn220_540"

><td id="540"><a href="#540">540</a></td></tr
><tr id="gr_svn220_541"

><td id="541"><a href="#541">541</a></td></tr
><tr id="gr_svn220_542"

><td id="542"><a href="#542">542</a></td></tr
><tr id="gr_svn220_543"

><td id="543"><a href="#543">543</a></td></tr
><tr id="gr_svn220_544"

><td id="544"><a href="#544">544</a></td></tr
><tr id="gr_svn220_545"

><td id="545"><a href="#545">545</a></td></tr
><tr id="gr_svn220_546"

><td id="546"><a href="#546">546</a></td></tr
><tr id="gr_svn220_547"

><td id="547"><a href="#547">547</a></td></tr
><tr id="gr_svn220_548"

><td id="548"><a href="#548">548</a></td></tr
><tr id="gr_svn220_549"

><td id="549"><a href="#549">549</a></td></tr
><tr id="gr_svn220_550"

><td id="550"><a href="#550">550</a></td></tr
><tr id="gr_svn220_551"

><td id="551"><a href="#551">551</a></td></tr
><tr id="gr_svn220_552"

><td id="552"><a href="#552">552</a></td></tr
><tr id="gr_svn220_553"

><td id="553"><a href="#553">553</a></td></tr
><tr id="gr_svn220_554"

><td id="554"><a href="#554">554</a></td></tr
><tr id="gr_svn220_555"

><td id="555"><a href="#555">555</a></td></tr
><tr id="gr_svn220_556"

><td id="556"><a href="#556">556</a></td></tr
><tr id="gr_svn220_557"

><td id="557"><a href="#557">557</a></td></tr
><tr id="gr_svn220_558"

><td id="558"><a href="#558">558</a></td></tr
><tr id="gr_svn220_559"

><td id="559"><a href="#559">559</a></td></tr
><tr id="gr_svn220_560"

><td id="560"><a href="#560">560</a></td></tr
><tr id="gr_svn220_561"

><td id="561"><a href="#561">561</a></td></tr
><tr id="gr_svn220_562"

><td id="562"><a href="#562">562</a></td></tr
><tr id="gr_svn220_563"

><td id="563"><a href="#563">563</a></td></tr
><tr id="gr_svn220_564"

><td id="564"><a href="#564">564</a></td></tr
><tr id="gr_svn220_565"

><td id="565"><a href="#565">565</a></td></tr
><tr id="gr_svn220_566"

><td id="566"><a href="#566">566</a></td></tr
><tr id="gr_svn220_567"

><td id="567"><a href="#567">567</a></td></tr
><tr id="gr_svn220_568"

><td id="568"><a href="#568">568</a></td></tr
><tr id="gr_svn220_569"

><td id="569"><a href="#569">569</a></td></tr
><tr id="gr_svn220_570"

><td id="570"><a href="#570">570</a></td></tr
><tr id="gr_svn220_571"

><td id="571"><a href="#571">571</a></td></tr
><tr id="gr_svn220_572"

><td id="572"><a href="#572">572</a></td></tr
><tr id="gr_svn220_573"

><td id="573"><a href="#573">573</a></td></tr
><tr id="gr_svn220_574"

><td id="574"><a href="#574">574</a></td></tr
><tr id="gr_svn220_575"

><td id="575"><a href="#575">575</a></td></tr
><tr id="gr_svn220_576"

><td id="576"><a href="#576">576</a></td></tr
><tr id="gr_svn220_577"

><td id="577"><a href="#577">577</a></td></tr
><tr id="gr_svn220_578"

><td id="578"><a href="#578">578</a></td></tr
><tr id="gr_svn220_579"

><td id="579"><a href="#579">579</a></td></tr
><tr id="gr_svn220_580"

><td id="580"><a href="#580">580</a></td></tr
><tr id="gr_svn220_581"

><td id="581"><a href="#581">581</a></td></tr
><tr id="gr_svn220_582"

><td id="582"><a href="#582">582</a></td></tr
><tr id="gr_svn220_583"

><td id="583"><a href="#583">583</a></td></tr
><tr id="gr_svn220_584"

><td id="584"><a href="#584">584</a></td></tr
><tr id="gr_svn220_585"

><td id="585"><a href="#585">585</a></td></tr
><tr id="gr_svn220_586"

><td id="586"><a href="#586">586</a></td></tr
><tr id="gr_svn220_587"

><td id="587"><a href="#587">587</a></td></tr
><tr id="gr_svn220_588"

><td id="588"><a href="#588">588</a></td></tr
><tr id="gr_svn220_589"

><td id="589"><a href="#589">589</a></td></tr
><tr id="gr_svn220_590"

><td id="590"><a href="#590">590</a></td></tr
><tr id="gr_svn220_591"

><td id="591"><a href="#591">591</a></td></tr
><tr id="gr_svn220_592"

><td id="592"><a href="#592">592</a></td></tr
><tr id="gr_svn220_593"

><td id="593"><a href="#593">593</a></td></tr
><tr id="gr_svn220_594"

><td id="594"><a href="#594">594</a></td></tr
><tr id="gr_svn220_595"

><td id="595"><a href="#595">595</a></td></tr
><tr id="gr_svn220_596"

><td id="596"><a href="#596">596</a></td></tr
><tr id="gr_svn220_597"

><td id="597"><a href="#597">597</a></td></tr
><tr id="gr_svn220_598"

><td id="598"><a href="#598">598</a></td></tr
><tr id="gr_svn220_599"

><td id="599"><a href="#599">599</a></td></tr
><tr id="gr_svn220_600"

><td id="600"><a href="#600">600</a></td></tr
><tr id="gr_svn220_601"

><td id="601"><a href="#601">601</a></td></tr
><tr id="gr_svn220_602"

><td id="602"><a href="#602">602</a></td></tr
><tr id="gr_svn220_603"

><td id="603"><a href="#603">603</a></td></tr
><tr id="gr_svn220_604"

><td id="604"><a href="#604">604</a></td></tr
><tr id="gr_svn220_605"

><td id="605"><a href="#605">605</a></td></tr
><tr id="gr_svn220_606"

><td id="606"><a href="#606">606</a></td></tr
><tr id="gr_svn220_607"

><td id="607"><a href="#607">607</a></td></tr
><tr id="gr_svn220_608"

><td id="608"><a href="#608">608</a></td></tr
><tr id="gr_svn220_609"

><td id="609"><a href="#609">609</a></td></tr
><tr id="gr_svn220_610"

><td id="610"><a href="#610">610</a></td></tr
><tr id="gr_svn220_611"

><td id="611"><a href="#611">611</a></td></tr
><tr id="gr_svn220_612"

><td id="612"><a href="#612">612</a></td></tr
><tr id="gr_svn220_613"

><td id="613"><a href="#613">613</a></td></tr
><tr id="gr_svn220_614"

><td id="614"><a href="#614">614</a></td></tr
><tr id="gr_svn220_615"

><td id="615"><a href="#615">615</a></td></tr
><tr id="gr_svn220_616"

><td id="616"><a href="#616">616</a></td></tr
><tr id="gr_svn220_617"

><td id="617"><a href="#617">617</a></td></tr
></table></pre>
<pre><table width="100%"><tr class="nocursor"><td></td></tr></table></pre>
</td>
<td id="lines">
<pre><table width="100%"><tr class="cursor_stop cursor_hidden"><td></td></tr></table></pre>
<pre class="prettyprint "><table id="src_table_0"><tr
id=sl_svn220_1

><td class="source">#ifndef OXS_CONFIG_h<br></td></tr
><tr
id=sl_svn220_2

><td class="source">#define OXS_CONFIG_h<br></td></tr
><tr
id=sl_svn220_3

><td class="source">// openxvario http://code.google.com/p/openxvario/<br></td></tr
><tr
id=sl_svn220_4

><td class="source">// started by R.SchloÃƒÅ¸han <br></td></tr
><tr
id=sl_svn220_5

><td class="source"><br></td></tr
><tr
id=sl_svn220_6

><td class="source"><br></td></tr
><tr
id=sl_svn220_7

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_8

><td class="source">// General explanation of the different options                                                          <br></td></tr
><tr
id=sl_svn220_9

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_10

><td class="source">//  This file allows the user to set up different options. Here a summary of the main options<br></td></tr
><tr
id=sl_svn220_11

><td class="source">//  1 - Protocol to be used to transmit data to Tx: it must be FRSKY_SPORT when using X serie Rx (X8R, X6R, ...) and NOT FRSKY_SPORT for D serie Rx<br></td></tr
><tr
id=sl_svn220_12

><td class="source">//  1.1 - Sensor_ID to be used for X serie receiver <br></td></tr
><tr
id=sl_svn220_13

><td class="source">//  2 - Hardware setting: in this section, you define which sensors are connected and on which arduino pin<br></td></tr
><tr
id=sl_svn220_14

><td class="source">//  2.1 - Digital pins used for Serial communication with TX, for reading a PPM signal from TX in order to adjust vario sensitivity, for checking a push button (reset some data) , for generating an analog signal based on vertical speed<br></td></tr
><tr
id=sl_svn220_15

><td class="source">//  2.2 - Analog pins used to measure voltages; it requires normally some voltage dividers (= set of 2 resistors)<br></td></tr
><tr
id=sl_svn220_16

><td class="source">//  2.3 - Analog pins used to measure current and consumption (it requires a cuurent sensor)<br></td></tr
><tr
id=sl_svn220_17

><td class="source">//  3 - General set up to define wich measurements are transmitted and how<br></td></tr
><tr
id=sl_svn220_18

><td class="source">//      This part specifies list of codes to be used and how to combine them<br></td></tr
><tr
id=sl_svn220_19

><td class="source">//  4 - Set up for vario (optional)<br></td></tr
><tr
id=sl_svn220_20

><td class="source">//  5 - Set up for current and voltage measurements (optional)<br></td></tr
><tr
id=sl_svn220_21

><td class="source">//  5.1 - Select the reference (VCC or 1.1 internal voltage reference)<br></td></tr
><tr
id=sl_svn220_22

><td class="source">//  5.2 - Calibration parameters for current sensor<br></td></tr
><tr
id=sl_svn220_23

><td class="source">//  5.3 - Calibration parameters for voltage measurements<br></td></tr
><tr
id=sl_svn220_24

><td class="source">//  5.4 - Number of lipo cells to measure (and transmit to Tx)<br></td></tr
><tr
id=sl_svn220_25

><td class="source">//  6 - Set up for RPM sensor<br></td></tr
><tr
id=sl_svn220_26

><td class="source">//  7 - Set up of Persistent memory <br></td></tr
><tr
id=sl_svn220_27

><td class="source">//<br></td></tr
><tr
id=sl_svn220_28

><td class="source">//  Note : active parameters are normally on a line begining by &quot;#define&quot; followed by the name of the parameter and sometime a value<br></td></tr
><tr
id=sl_svn220_29

><td class="source">//         To deactivate a parameter, in general, you can add &quot;//&quot; just before &quot;#define&quot;; this line will then be considered as a comment and discarded <br></td></tr
><tr
id=sl_svn220_30

><td class="source">//         Take care that in special cases (see below - e.g. for Pin_Voltage ) the parameter must always be present but can be deactivated using a special value   <br></td></tr
><tr
id=sl_svn220_31

><td class="source">//  Note: it could be that the combination of active/non active parameters as currently defined in this document is not consistent (e.g. it make no sense to activate PPM is there is no Vario sensor)<br></td></tr
><tr
id=sl_svn220_32

><td class="source">//        This is just the result of many updates in this document.<br></td></tr
><tr
id=sl_svn220_33

><td class="source"><br></td></tr
><tr
id=sl_svn220_34

><td class="source"><br></td></tr
><tr
id=sl_svn220_35

><td class="source">//**** 1 FrSky protocol to be used  *********************************************************************************<br></td></tr
><tr
id=sl_svn220_36

><td class="source">// There are 2 different protocols:<br></td></tr
><tr
id=sl_svn220_37

><td class="source">//   - SPORT is used for X serie receivers (like X8R or X6R)<br></td></tr
><tr
id=sl_svn220_38

><td class="source">//   - HUB is used for D serie receivers (like D4R-II)<br></td></tr
><tr
id=sl_svn220_39

><td class="source">//  Currently, XOS does not automatically detect the type of receiver it is connected to<br></td></tr
><tr
id=sl_svn220_40

><td class="source">//  So you have to specify the protocol to upload in the arduino and you have to reload the program with another protocol if you want to use the same hardware OXS on another type of receiver<br></td></tr
><tr
id=sl_svn220_41

><td class="source">//<br></td></tr
><tr
id=sl_svn220_42

><td class="source">//  In SPORT protocol, there may be several sensors connected on the same bus but each sensor must have a different SENSOR_ID<br></td></tr
><tr
id=sl_svn220_43

><td class="source">//  The SENSOR_ID has no impact for the HUB protocol<br></td></tr
><tr
id=sl_svn220_44

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_45

><td class="source">#define FRSKY_SPORT	   // put this line as comment if OXS is connected to a D serie receiver ( = Hub protocol); do not comment for X serie receiver.<br></td></tr
><tr
id=sl_svn220_46

><td class="source">#define SENSOR_ID    0x1B  // this parameter identifies a device connected on SPORT. It is not allowed having 2 devices with the same ID connected at the same time<br></td></tr
><tr
id=sl_svn220_47

><td class="source">                           // valid values are 0x1B, 0xBA, ... (there are 28 values)     <br></td></tr
><tr
id=sl_svn220_48

><td class="source"><br></td></tr
><tr
id=sl_svn220_49

><td class="source"><br></td></tr
><tr
id=sl_svn220_50

><td class="source">						   //**** 2 Hardware settings ************************************************************<br></td></tr
><tr
id=sl_svn220_51

><td class="source">// Here you can specify which pins will be used for which connection <br></td></tr
><tr
id=sl_svn220_52

><td class="source">// Arduino has:<br></td></tr
><tr
id=sl_svn220_53

><td class="source">//    - digital pin (named 0, 1, ...13)<br></td></tr
><tr
id=sl_svn220_54

><td class="source">//    - analog pin (named A0, A1, ... A8); the number of pins can vary depending on the arduino board<br></td></tr
><tr
id=sl_svn220_55

><td class="source">//**** 2.1 Digital pins *********************************************************************************<br></td></tr
><tr
id=sl_svn220_56

><td class="source">#define PIN_SerialTX        4  // The pin to transmit the serial data to the frsky telemetry enabled receiver<br></td></tr
><tr
id=sl_svn220_57

><td class="source">                               // It is a DIGITAL arduino pin that has to be connected to &quot;Rx&quot; pin from receiver (for D serie RX) or to Signal pin (for X serie RX)<br></td></tr
><tr
id=sl_svn220_58

><td class="source">                               // mandatory ; default: 4 ; allowed values are 0 up to 7 but take care not using the same pin as PPM (if PPM is used) <br></td></tr
><tr
id=sl_svn220_59

><td class="source"><br></td></tr
><tr
id=sl_svn220_60

><td class="source">//#define PIN_PPM           2  // Arduino can read a PPM Signal coming from Tx. This allows to change the vario sensitivity using a pot or a switch on TX.<br></td></tr
><tr
id=sl_svn220_61

><td class="source">                               // It is a DIGITAL arduino pin that has to be connected to a signal channel from receiver (like for a servo)<br></td></tr
><tr
id=sl_svn220_62

><td class="source">                               // optional; default: 2 ; you can also use pin 3 to read the PPM signal<br></td></tr
><tr
id=sl_svn220_63

><td class="source">                               // take care, only pin 2 or 3 may be used for PPM signal    <br></td></tr
><tr
id=sl_svn220_64

><td class="source">                               // Put this line as comment if you want to disable the remote control functionality<br></td></tr
><tr
id=sl_svn220_65

><td class="source"><br></td></tr
><tr
id=sl_svn220_66

><td class="source"><br></td></tr
><tr
id=sl_svn220_67

><td class="source">//#define PIN_PushButton    10  // Arduino can check if a push button has been pushed in order to reset some values (consumption, max altititude, max current, ...)<br></td></tr
><tr
id=sl_svn220_68

><td class="source">                               // normally most of those parameters shoud best be kept on Tx side but I think it is not possible for current consumption<br></td></tr
><tr
id=sl_svn220_69

><td class="source">                               // It is a DIGITAL arduino pin that has to be connected to a push button, the other pin of the push button being connected to Gnd (ground)<br></td></tr
><tr
id=sl_svn220_70

><td class="source">                               // optional; default: 10 ; Do not use a pin that is already used for another purpose<br></td></tr
><tr
id=sl_svn220_71

><td class="source">                               // Put this line as comment to completly disable button code<br></td></tr
><tr
id=sl_svn220_72

><td class="source">                               <br></td></tr
><tr
id=sl_svn220_73

><td class="source">//#define PIN_AnalogClimbRate 3  // 3 the pin used to optionally write the vertical speed to the Rx a1 or a2 pin (can be 3 or 11 because it has to use timer 2)<br></td></tr
><tr
id=sl_svn220_74

><td class="source"><br></td></tr
><tr
id=sl_svn220_75

><td class="source">// Note : The digital pin 8 (PB0/ICP) is the only one to be used to measure RPM <br></td></tr
><tr
id=sl_svn220_76

><td class="source"><br></td></tr
><tr
id=sl_svn220_77

><td class="source">                            <br></td></tr
><tr
id=sl_svn220_78

><td class="source">//**** 2.2 Analog Pins for voltages *********************************************************************************<br></td></tr
><tr
id=sl_svn220_79

><td class="source">//   Analog pins can be used to measure up to 6 input voltages (please note that, depending on manufacter, some Arduino pro mini have less Analog pin available) <br></td></tr
><tr
id=sl_svn220_80

><td class="source">//   A voltage can be provided by a battery (e.g. a multicell lipo) or a sensor (e.g. a temperature sensor convert the temperature in a voltage that can be measured) <br></td></tr
><tr
id=sl_svn220_81

><td class="source">//   Note : one Analog pin can also be used to measure a current using a current sensor; the set up for a current sensor is described in section 2.3 (see below);<br></td></tr
><tr
id=sl_svn220_82

><td class="source">//          in this case, only 5 voltages can be measured because Arduino has no enough Analog pin<br></td></tr
><tr
id=sl_svn220_83

><td class="source">//   The Pin value (on arduino) is a number from 0 up to 7 (0 means A0 = Analog 0, 1 means A1, ...7 means A7)<br></td></tr
><tr
id=sl_svn220_84

><td class="source">// !! Take care that the voltage applied to Arduino pin may not exceed Vcc (normally 5 volt) or 1.1 volt (if internal reference volatge is used).<br></td></tr
><tr
id=sl_svn220_85

><td class="source">//   It can be that you have to use voltage divider in order to reduce the voltage applied on arduino pin compare to the voltage you want to measure<br></td></tr
><tr
id=sl_svn220_86

><td class="source">//    See explanation below about voltage divider and about using VCC or 1.1 internal voltage divider.<br></td></tr
><tr
id=sl_svn220_87

><td class="source">//   Note : all voltages are measured to ground; so, for a multicell lipo, it will be max 4.2 volt for the first cell, 8.4 for the second, 12.6 for the third,... <br></td></tr
><tr
id=sl_svn220_88

><td class="source">//   <br></td></tr
><tr
id=sl_svn220_89

><td class="source">//   If there is no need to measure 6 voltage, DO NOT SET the line AS COMMENT BUT SET THE VALUE = 8                                         <br></td></tr
><tr
id=sl_svn220_90

><td class="source">//   Note :even if it does not make much sense ,the same pin value can be used for several PIN_Voltages (the voltage on this pin will then be measured for each PIN_Voltage setup)                                            <br></td></tr
><tr
id=sl_svn220_91

><td class="source">//   Take care : do NOT use pins 4 and 5 if you use a vario                             <br></td></tr
><tr
id=sl_svn220_92

><td class="source">//               (those pins are reserved for the barometric sensor)                   <br></td></tr
><tr
id=sl_svn220_93

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_94

><td class="source">#define PIN_Voltage1 8    //  Pin for measuring Voltage 1 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_95

><td class="source">#define PIN_Voltage2 8    //  Pin for measuring Voltage 2 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_96

><td class="source">#define PIN_Voltage3 8    //  Pin for measuring Voltage 3 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_97

><td class="source">#define PIN_Voltage4 8    //  Pin for measuring Voltage 4 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_98

><td class="source">#define PIN_Voltage5 8    //  Pin for measuring Voltage 5 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_99

><td class="source">#define PIN_Voltage6 8    //  Pin for measuring Voltage 6 ( Analog In Pin! )<br></td></tr
><tr
id=sl_svn220_100

><td class="source"><br></td></tr
><tr
id=sl_svn220_101

><td class="source"><br></td></tr
><tr
id=sl_svn220_102

><td class="source">//**** 2.3 Analog pin used for curent sensor *********************************************************************************<br></td></tr
><tr
id=sl_svn220_103

><td class="source">//   It is possible to measure a current (and current comsumption) if a current sensor is connected.<br></td></tr
><tr
id=sl_svn220_104

><td class="source">//   This current sensor returns a voltage that depends on the current. This voltage is measured by the arduino via an Analog pin<br></td></tr
><tr
id=sl_svn220_105

><td class="source">//   The Pin value (on arduino) is a number from 0 up to 7 (0 means A0, 1 means A1, ...7 means A7)<br></td></tr
><tr
id=sl_svn220_106

><td class="source">//   If a current sensor is used, better not to use a pin that is already used by a voltage.<br></td></tr
><tr
id=sl_svn220_107

><td class="source">// !! Take care that the voltage applied to Arduino pin may not exceed Vcc (normally 5 volt) or 1.1 volt (if internal reference volatge is used).<br></td></tr
><tr
id=sl_svn220_108

><td class="source">//   It can be that you have to use voltage divider in order to reduce the voltage applied on arduino pin<br></td></tr
><tr
id=sl_svn220_109

><td class="source">//    see explanation below about voltage divider<br></td></tr
><tr
id=sl_svn220_110

><td class="source">//   Take care : do NOT use pins 4 and 5 if you use a vario                             <br></td></tr
><tr
id=sl_svn220_111

><td class="source">//               (those pins are reserved for the barometric sensor)                   <br></td></tr
><tr
id=sl_svn220_112

><td class="source">// note : The current sensor is normally powered by the 5 volt VCC from Arduino (same as the vario sensor)<br></td></tr
><tr
id=sl_svn220_113

><td class="source">//        There are bidirectional sensor and unidirectional sensor.<br></td></tr
><tr
id=sl_svn220_114

><td class="source">//        For bidirectional, output is normally equal to VCC/2 when current = 0 Amp, for unidirectional, output is normally 0,6 volt at 0 Amp.<br></td></tr
><tr
id=sl_svn220_115

><td class="source">//        If OXS is connected to a battery giving less than 5.2 volt, the supply voltage for the current sensor will vary with the OXS supply voltage.<br></td></tr
><tr
id=sl_svn220_116

><td class="source">//        Therefore VCC/2 ( = O amp) will varies with VCC<br></td></tr
><tr
id=sl_svn220_117

><td class="source">//        This is an issue if the arduino ADC is configured to use the 1.1 volt internal reference.<br></td></tr
><tr
id=sl_svn220_118

><td class="source">//        So, in this case it is better to configure the ADC in order to use VCC as reference for conversion.<br></td></tr
><tr
id=sl_svn220_119

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_120

><td class="source">#define PIN_CurrentSensor   2  // The Analog pin the optional current Sensor is connected to (2 = pin A2)<br></td></tr
><tr
id=sl_svn220_121

><td class="source"><br></td></tr
><tr
id=sl_svn220_122

><td class="source"><br></td></tr
><tr
id=sl_svn220_123

><td class="source"><br></td></tr
><tr
id=sl_svn220_124

><td class="source">//**** 3 Fields to transmit **************************************************************************************<br></td></tr
><tr
id=sl_svn220_125

><td class="source">// Each field send to TX has an field ID; this field_ID let TX know which kind of value it receives and how to use it. Codes are normally different for SPORT and for HUB protocols<br></td></tr
><tr
id=sl_svn220_126

><td class="source">// In some cases, it is possible to let Arduino automatically select the right code using &quot;DEFAULTFIELD&quot; (see below).<br></td></tr
><tr
id=sl_svn220_127

><td class="source">// Each data that Arduino can transmit has also a code in order to identify the data<br></td></tr
><tr
id=sl_svn220_128

><td class="source">// In this section, you must specify which telemetry field_ID has to be used to transmit which data measured/calculated by Arduino<br></td></tr
><tr
id=sl_svn220_129

><td class="source">//****3.1 Telemetry fields for SPORT **************************************************************<br></td></tr
><tr
id=sl_svn220_130

><td class="source">// This is the list of all (main) telemetry fields supported by SPORT  (X serie Rx) (NB: the codes are defined by Frsky)     <br></td></tr
><tr
id=sl_svn220_131

><td class="source">// Note : some of those values may not (yet) be displayed on Taranis<br></td></tr
><tr
id=sl_svn220_132

><td class="source">// You can use code from this list when you in which telemetry field a measurent has to be transmitted<br></td></tr
><tr
id=sl_svn220_133

><td class="source">//     See below for more explanation<br></td></tr
><tr
id=sl_svn220_134

><td class="source">//     Do not modify this list <br></td></tr
><tr
id=sl_svn220_135

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_136

><td class="source">//#define RSSI_ID            0xf101  // please do not use this code because it is already used by the receiver<br></td></tr
><tr
id=sl_svn220_137

><td class="source">//#define ADC1_ID            0xf102  // please do not use this code because it is already used by the receiver<br></td></tr
><tr
id=sl_svn220_138

><td class="source">#define ADC2_ID            0xf103  <br></td></tr
><tr
id=sl_svn220_139

><td class="source">#define BATT_ID            0xf104<br></td></tr
><tr
id=sl_svn220_140

><td class="source">//#define SWR_ID             0xf105   // please do not use this code because it is already used by the receiver<br></td></tr
><tr
id=sl_svn220_141

><td class="source">#define T1_FIRST_ID        0x0400<br></td></tr
><tr
id=sl_svn220_142

><td class="source">#define T1_LAST_ID         0x040f<br></td></tr
><tr
id=sl_svn220_143

><td class="source">#define T2_FIRST_ID        0x0410<br></td></tr
><tr
id=sl_svn220_144

><td class="source">#define T2_LAST_ID         0x041f<br></td></tr
><tr
id=sl_svn220_145

><td class="source">#define RPM_FIRST_ID       0x0500<br></td></tr
><tr
id=sl_svn220_146

><td class="source">#define RPM_LAST_ID        0x050f<br></td></tr
><tr
id=sl_svn220_147

><td class="source">#define FUEL_FIRST_ID      0x0600<br></td></tr
><tr
id=sl_svn220_148

><td class="source">#define FUEL_LAST_ID       0x060f<br></td></tr
><tr
id=sl_svn220_149

><td class="source">#define ALT_FIRST_ID       0x0100<br></td></tr
><tr
id=sl_svn220_150

><td class="source">#define ALT_LAST_ID        0x010f<br></td></tr
><tr
id=sl_svn220_151

><td class="source">#define VARIO_FIRST_ID     0x0110<br></td></tr
><tr
id=sl_svn220_152

><td class="source">#define VARIO_LAST_ID      0x011f<br></td></tr
><tr
id=sl_svn220_153

><td class="source">#define ACCX_FIRST_ID      0x0700<br></td></tr
><tr
id=sl_svn220_154

><td class="source">#define ACCX_LAST_ID       0x070f<br></td></tr
><tr
id=sl_svn220_155

><td class="source">#define ACCY_FIRST_ID      0x0710<br></td></tr
><tr
id=sl_svn220_156

><td class="source">#define ACCY_LAST_ID       0x071f<br></td></tr
><tr
id=sl_svn220_157

><td class="source">#define ACCZ_FIRST_ID      0x0720<br></td></tr
><tr
id=sl_svn220_158

><td class="source">#define ACCZ_LAST_ID       0x072f<br></td></tr
><tr
id=sl_svn220_159

><td class="source">#define CURR_FIRST_ID      0x0200<br></td></tr
><tr
id=sl_svn220_160

><td class="source">#define CURR_LAST_ID       0x020f<br></td></tr
><tr
id=sl_svn220_161

><td class="source">#define VFAS_FIRST_ID      0x0210<br></td></tr
><tr
id=sl_svn220_162

><td class="source">#define VFAS_LAST_ID       0x021f<br></td></tr
><tr
id=sl_svn220_163

><td class="source">#define GPS_SPEED_FIRST_ID 0x0830<br></td></tr
><tr
id=sl_svn220_164

><td class="source">#define GPS_SPEED_LAST_ID  0x083f<br></td></tr
><tr
id=sl_svn220_165

><td class="source">#define CELLS_FIRST_ID     0x0300<br></td></tr
><tr
id=sl_svn220_166

><td class="source">#define CELLS_SECOND_ID    0x0301<br></td></tr
><tr
id=sl_svn220_167

><td class="source">#define CELLS_THIRD_ID     0x0302<br></td></tr
><tr
id=sl_svn220_168

><td class="source">#define CELLS_LAST_ID      0x030f<br></td></tr
><tr
id=sl_svn220_169

><td class="source">// End of list of all telemetry fields supported by SPORT  (defined by Frsky) <br></td></tr
><tr
id=sl_svn220_170

><td class="source"><br></td></tr
><tr
id=sl_svn220_171

><td class="source"><br></td></tr
><tr
id=sl_svn220_172

><td class="source">//**** 3.2 Telemetry fields for Hub *************************************************************<br></td></tr
><tr
id=sl_svn220_173

><td class="source">// This is the list of all (main) telemetry fields supported by Hub protocol ( = D serie receivers)  (code are defined by Frsky)     <br></td></tr
><tr
id=sl_svn220_174

><td class="source">// You can use code from this list when you define in which telemetry field a measurent has to be transmitted<br></td></tr
><tr
id=sl_svn220_175

><td class="source">//     See below for more explanation<br></td></tr
><tr
id=sl_svn220_176

><td class="source">//     Do not modify this list <br></td></tr
><tr
id=sl_svn220_177

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_178

><td class="source">#define FRSKY_USERDATA_GPS_ALT_B    0x01<br></td></tr
><tr
id=sl_svn220_179

><td class="source">#define FRSKY_USERDATA_TEMP1        0x02<br></td></tr
><tr
id=sl_svn220_180

><td class="source">#define FRSKY_USERDATA_RPM          0x03<br></td></tr
><tr
id=sl_svn220_181

><td class="source">#define FRSKY_USERDATA_FUEL         0x04<br></td></tr
><tr
id=sl_svn220_182

><td class="source">#define FRSKY_USERDATA_TEMP2        0x05<br></td></tr
><tr
id=sl_svn220_183

><td class="source">#define FRSKY_USERDATA_CELL_VOLT    0x06<br></td></tr
><tr
id=sl_svn220_184

><td class="source">#define FRSKY_USERDATA_GPS_ALT_A    0x09<br></td></tr
><tr
id=sl_svn220_185

><td class="source">#define FRSKY_USERDATA_BARO_ALT_B   0x10<br></td></tr
><tr
id=sl_svn220_186

><td class="source">#define FRSKY_USERDATA_GPS_SPEED_B  0x11<br></td></tr
><tr
id=sl_svn220_187

><td class="source">#define FRSKY_USERDATA_GPS_LONG_B   0x12<br></td></tr
><tr
id=sl_svn220_188

><td class="source">#define FRSKY_USERDATA_GPS_LAT_B    0x13<br></td></tr
><tr
id=sl_svn220_189

><td class="source">#define FRSKY_USERDATA_GPS_CURSE_B  0x14<br></td></tr
><tr
id=sl_svn220_190

><td class="source">#define FRSKY_USERDATA_GPS_DM       0x15<br></td></tr
><tr
id=sl_svn220_191

><td class="source">#define FRSKY_USERDATA_GPS_YEAR     0x16<br></td></tr
><tr
id=sl_svn220_192

><td class="source">#define FRSKY_USERDATA_GPS_HM       0x17<br></td></tr
><tr
id=sl_svn220_193

><td class="source">#define FRSKY_USERDATA_GPS_SEC      0x18<br></td></tr
><tr
id=sl_svn220_194

><td class="source">#define FRSKY_USERDATA_GPS_SPEED_A  0x19<br></td></tr
><tr
id=sl_svn220_195

><td class="source">#define FRSKY_USERDATA_GPS_LONG_A   0x1A<br></td></tr
><tr
id=sl_svn220_196

><td class="source">#define FRSKY_USERDATA_GPS_LAT_A    0x1B<br></td></tr
><tr
id=sl_svn220_197

><td class="source">#define FRSKY_USERDATA_GPS_CURSE_A  0x1C<br></td></tr
><tr
id=sl_svn220_198

><td class="source">#define FRSKY_USERDATA_BARO_ALT_A   0x21<br></td></tr
><tr
id=sl_svn220_199

><td class="source">#define FRSKY_USERDATA_GPS_LONG_EW  0x22<br></td></tr
><tr
id=sl_svn220_200

><td class="source">#define FRSKY_USERDATA_GPS_LAT_EW   0x23<br></td></tr
><tr
id=sl_svn220_201

><td class="source">#define FRSKY_USERDATA_ACC_X        0x24<br></td></tr
><tr
id=sl_svn220_202

><td class="source">#define FRSKY_USERDATA_ACC_Y        0x25<br></td></tr
><tr
id=sl_svn220_203

><td class="source">#define FRSKY_USERDATA_ACC_Z        0x26<br></td></tr
><tr
id=sl_svn220_204

><td class="source">#define FRSKY_USERDATA_CURRENT      0x28<br></td></tr
><tr
id=sl_svn220_205

><td class="source">#define FRSKY_USERDATA_VERT_SPEED   0x30 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_206

><td class="source">#define FRSKY_USERDATA_ALT_MIN      0x31 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_207

><td class="source">#define FRSKY_USERDATA_ALT_MAX      0x32 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_208

><td class="source">#define FRSKY_USERDATA_RPM_MAX      0x33 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_209

><td class="source">#define FRSKY_USERDATA_T1_MAX       0x34 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_210

><td class="source">#define FRSKY_USERDATA_T2_MAX       0x35 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_211

><td class="source">#define FRSKY_USERDATA_GPS_SPEED_MAX  0x36 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_212

><td class="source">#define FRSKY_USERDATA_GPS_DIS_MAX  0x37 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_213

><td class="source">#define FRSKY_USERDATA_VFAS_NEW     0x39 // open9x Vario Mode Only<br></td></tr
><tr
id=sl_svn220_214

><td class="source">#define FRSKY_USERDATA_VOLTAGE_B    0x3A<br></td></tr
><tr
id=sl_svn220_215

><td class="source">#define FRSKY_USERDATA_VOLTAGE_A    0x3B<br></td></tr
><tr
id=sl_svn220_216

><td class="source">#define FRSKY_USERDATA_GPS_DIST     0x3C<br></td></tr
><tr
id=sl_svn220_217

><td class="source">#define FRSKY_USERDATA_FUELPERCENT  0x3D<br></td></tr
><tr
id=sl_svn220_218

><td class="source">// End of list of all telemetry fields supported by Hub protocol (defined by Frsky) <br></td></tr
><tr
id=sl_svn220_219

><td class="source"><br></td></tr
><tr
id=sl_svn220_220

><td class="source"><br></td></tr
><tr
id=sl_svn220_221

><td class="source">//**** 3.3 Telemetry field both for SPORT and HUB *************************************************<br></td></tr
><tr
id=sl_svn220_222

><td class="source">// The value DEFAULTFIELD can be used to say that the measurement has to be transmitted using the normal field for this type of measurement.<br></td></tr
><tr
id=sl_svn220_223

><td class="source">// This value is valid for both protocols ( = types of receiver = D and X series); Arduino will automatically select the right field_ID taking care of the selected protocol and of the measurement)<br></td></tr
><tr
id=sl_svn220_224

><td class="source">// Still not all measurements have a DEFAULTFIELD and on the opposite, some measurement are structure in such a special way, that only DEFULTFIELD makes sense.<br></td></tr
><tr
id=sl_svn220_225

><td class="source">// In order to know for wich measurement DEFAULTFIELD value is allowed or must be used, look at the comments in section 3.4 below.<br></td></tr
><tr
id=sl_svn220_226

><td class="source">// Note: in the Hub protocol (D serie receiver), DEFAULTFIELD option does not work 100% the same way as the equivalent field_ID for some measurement. That the case for  <br></td></tr
><tr
id=sl_svn220_227

><td class="source">//       ALTIMETER (Hub protocol requires sending different fields for Meters and Centimeters)<br></td></tr
><tr
id=sl_svn220_228

><td class="source">//       VERTICAL_SPEED (In Hub protocol that are some conversion of value 0.10 and -0.10 into 0.09 and -0.09 because it seems that some version had an issue)<br></td></tr
><tr
id=sl_svn220_229

><td class="source">//       CURRENTMA (in Hub protocol, with DEFAULTFIELD , Arduino takes the absolute value of current in milliAmp), divide it automatically by 100 (so no additional multiplier/divider is needed)<br></td></tr
><tr
id=sl_svn220_230

><td class="source">// Note: in the hub protocol, when DEFAULTFIELD is used, Aduinino do NOT apply the multiplier/divider/offset (because some fields have already a special formatting inside Arduino (see here above)<br></td></tr
><tr
id=sl_svn220_231

><td class="source"><br></td></tr
><tr
id=sl_svn220_232

><td class="source">#define DEFAULTFIELD                0x00 <br></td></tr
><tr
id=sl_svn220_233

><td class="source">                                                  <br></td></tr
><tr
id=sl_svn220_234

><td class="source"><br></td></tr
><tr
id=sl_svn220_235

><td class="source"><br></td></tr
><tr
id=sl_svn220_236

><td class="source">//**** 3.4  Data that can be transmitted to Tx *************************************************<br></td></tr
><tr
id=sl_svn220_237

><td class="source">//  This is the list of codes for each available measurements<br></td></tr
><tr
id=sl_svn220_238

><td class="source">//  Do not change those values<br></td></tr
><tr
id=sl_svn220_239

><td class="source">//  Use those codes when you define which data has to be transmitted (see below) <br></td></tr
><tr
id=sl_svn220_240

><td class="source">#define ALTIMETER       1        // DEFAULTFIELD can be used in SPORT protocol (is then the same as ALT_FIRST_ID);  it MUST be used in Hub protocol because meters and centimeters are send in different fileds<br></td></tr
><tr
id=sl_svn220_241

><td class="source">#define VERTICAL_SPEED  2        // DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_242

><td class="source">#define SENSITIVITY     3        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_243

><td class="source">#define ALT_OVER_10_SEC 4        // DEFAULTFIELD can NOT be used ; this is the difference of altitude over the last 10 sec (kind of averaging vertical speed)<br></td></tr
><tr
id=sl_svn220_244

><td class="source">                                 // there is no telemetry field for this; it is possible to use e.g. T1 or T2; then you can use a custom function &quot;play value&quot; on Tx side<br></td></tr
><tr
id=sl_svn220_245

><td class="source">#define VOLT1           5        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_246

><td class="source">#define VOLT2           6        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_247

><td class="source">#define VOLT3           7        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_248

><td class="source">#define VOLT4           8        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_249

><td class="source">#define VOLT5           9        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_250

><td class="source">#define VOLT6           10        // DEFAULTFIELD can NOT be used<br></td></tr
><tr
id=sl_svn220_251

><td class="source">#define CURRENTMA       11        // DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_252

><td class="source">#define MILLIAH         12        // if value must be sent as percentage, then uncomment the line &quot;#define SEND_mAhPercentageAsFuel 4000&quot; (see below)<br></td></tr
><tr
id=sl_svn220_253

><td class="source">#define CELLS_1_2       13        // Only DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_254

><td class="source">#define CELLS_3_4       14        // Only DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_255

><td class="source">#define CELLS_5_6       15        // Only DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_256

><td class="source">#define RPM             16        // Only DEFAULTFIELD can be used<br></td></tr
><tr
id=sl_svn220_257

><td class="source">// to do : add alt min, alt max ,  rpm max? , current max (not sure that it is neaded because it can be calculated on TX side<br></td></tr
><tr
id=sl_svn220_258

><td class="source">// End of list of type of available measurements<br></td></tr
><tr
id=sl_svn220_259

><td class="source"><br></td></tr
><tr
id=sl_svn220_260

><td class="source"><br></td></tr
><tr
id=sl_svn220_261

><td class="source">//**** 3.5 General set up to define wich measurements are transmitted and how **********************************************************************<br></td></tr
><tr
id=sl_svn220_262

><td class="source">// You MUST specify here under ONE ROW for EACH FIELD to tranmit to Tx.<br></td></tr
><tr
id=sl_svn220_263

><td class="source">// Each row must contains:<br></td></tr
><tr
id=sl_svn220_264

><td class="source">//   - 1 : the code of a field to transmit (e.g. &quot;T1_FIRST_ID&quot; ) (!! see note (1) below)<br></td></tr
><tr
id=sl_svn220_265

><td class="source">//   - 2 : a comma <br></td></tr
><tr
id=sl_svn220_266

><td class="source">//   - 3 : the code of a measurement to transmit in this field (e.g. &quot;VOLT1&quot;)  (see note (2))<br></td></tr
><tr
id=sl_svn220_267

><td class="source">//   - 4 : a comma <br></td></tr
><tr
id=sl_svn220_268

><td class="source">//   - 5 : a multiplier factor to apply on the value to transmitted (set &quot;1&quot; to keep the original measurement, 10 to multiply by 10 , ...) (see note (3)) <br></td></tr
><tr
id=sl_svn220_269

><td class="source">//   - 6 : a comma <br></td></tr
><tr
id=sl_svn220_270

><td class="source">//   - 7 : a divider factor to apply on the value to transmitted (set &quot;1&quot; to keep the original measurement, 10 to divide by 10 , ...)  (see note (3))<br></td></tr
><tr
id=sl_svn220_271

><td class="source">//   - 8 : a comma<br></td></tr
><tr
id=sl_svn220_272

><td class="source">//   - 9 : an offset factor to apply after having applied the multiplier and divider ((set &quot;0&quot; to keep the original measurement, &quot;100&quot; to add 100, ...)<br></td></tr
><tr
id=sl_svn220_273

><td class="source">//   - 10 : a comma and &quot;\&quot; if there is least one next more (don&#39;t fill on the last row);<br></td></tr
><tr
id=sl_svn220_274

><td class="source">//                  TAKE CARE that &quot;\&quot; MUST be the LAST character on the row (even no space after)<br></td></tr
><tr
id=sl_svn220_275

><td class="source">//                  TAKE CARE that no comment lines (&quot;//...&quot;) may exist between rows<br></td></tr
><tr
id=sl_svn220_276

><td class="source">//<br></td></tr
><tr
id=sl_svn220_277

><td class="source">// Note (1) : The code of a field to transmit is normally to select in the list of fields for SPORT or for HUB protocol depending on the protocol (= serie Rx) you are using<br></td></tr
><tr
id=sl_svn220_278

><td class="source">//            Do not use code foreseen for SPORT when you use a D serie receiver.<br></td></tr
><tr
id=sl_svn220_279

><td class="source">//            The opposite will perhaps (?) works but it is safier to avoid it. <br></td></tr
><tr
id=sl_svn220_280

><td class="source">//            In some cases (see  &quot;Data that can be transmitted to Tx&quot; here above), you can/must specify the value &quot;DEFAULTFIELD&quot;. It means that Arduino will automatically transmit the data in the most normal foreseen field.<br></td></tr
><tr
id=sl_svn220_281

><td class="source">//            A code of a field to transmit (e.g. &quot;T1_FIRST_ID&quot; ) may not appear on several rows<br></td></tr
><tr
id=sl_svn220_282

><td class="source">//            Sequence of rows does not matter.<br></td></tr
><tr
id=sl_svn220_283

><td class="source">// Note (2) : A code of a measurement (e.g. VOLT1) may not appear on several rows<br></td></tr
><tr
id=sl_svn220_284

><td class="source">// Note (3) : Multiplier, divider and offset must be integer (no decimal); they can be negative (e.g. &quot;-100&quot;)<br></td></tr
><tr
id=sl_svn220_285

><td class="source">//            Multiplier and divider can be useful e.g.<br></td></tr
><tr
id=sl_svn220_286

><td class="source">//                     - to convert in other measurement system (meter &lt;&gt; foot)<br></td></tr
><tr
id=sl_svn220_287

><td class="source">//                     - to convert in percentage (e.g. multiply by 100 and divide by 4000 in order to get the consumption of current in % for a 4000 mAmph accu)<br></td></tr
><tr
id=sl_svn220_288

><td class="source">//                     - to adjust the number of digits displayed on Tx telemetry screen.<br></td></tr
><tr
id=sl_svn220_289

><td class="source">//                     - to have e.g. a fuel value starting at 100 (in percent) and going down to 0 when consumption increase (then you must use a negative multiplier and an offset of 100%).<br></td></tr
><tr
id=sl_svn220_290

><td class="source">//            Multiplier/divider/offset must be set up but they are not always taken into account by XOS; it is the case when:<br></td></tr
><tr
id=sl_svn220_291

><td class="source">//                  - CELLS_1_2, CELLS_3_4, CELLS_5_6 is transmitted (because those fields have a special formatting required by Tx<br></td></tr
><tr
id=sl_svn220_292

><td class="source">//                  - Field_ID is defined using the option DEFAULTFIELD combined with a Hub protocol (D serie Rx) because special formatting are applied (see 3.3 above)<br></td></tr
><tr
id=sl_svn220_293

><td class="source">// Here an example of set up in order to transmit on SPORT protocol<br></td></tr
><tr
id=sl_svn220_294

><td class="source">//    - as Altitude : the altitude measurement,<br></td></tr
><tr
id=sl_svn220_295

><td class="source">//    - as Vertical speed : the vertical speed measurement<br></td></tr
><tr
id=sl_svn220_296

><td class="source">//    - as Current : the current measurement<br></td></tr
><tr
id=sl_svn220_297

><td class="source">//    - as Fuel : the current consumption in % for an accu of 4000mAmph starting at 100% <br></td></tr
><tr
id=sl_svn220_298

><td class="source">//    - as Temperature T1 : the VOLT6 measurement divided by 100<br></td></tr
><tr
id=sl_svn220_299

><td class="source">//               #define SETUP_DATA_TO_SEND    \<br></td></tr
><tr
id=sl_svn220_300

><td class="source">//                        DEFAULTFIELD , ALTIMETER , 1 , 1 , 0 ,\<br></td></tr
><tr
id=sl_svn220_301

><td class="source">//                        DEFAULTFIELD , VERTICAL_SPEED , 1 , 1 ,0 ,\<br></td></tr
><tr
id=sl_svn220_302

><td class="source">//                        DEFAULTFIELD , CURRENTMA , 1 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_303

><td class="source">//                        FUEL_FIRST_ID , MILLIAH , -100 , 4000 ,0, \<br></td></tr
><tr
id=sl_svn220_304

><td class="source">//                        T1_FIRST_ID , VOLT6, 1 , 100, 0<br></td></tr
><tr
id=sl_svn220_305

><td class="source">// When the Cell voltages have to be transmitted, the voltages are transmitted by group of 2 over SPORT protocol.<br></td></tr
><tr
id=sl_svn220_306

><td class="source">//    For uniformity, the cell voltages are also calculated/saved by group of 2 for the Hub protocol even if they are all transmitted in one frame.<br></td></tr
><tr
id=sl_svn220_307

><td class="source">//    So in both cases, the number of row to complete is the number of cells you have divided by 2 and rounded up to the higher integer value.<br></td></tr
><tr
id=sl_svn220_308

><td class="source">//    E.g. for a lipo with 3 cells, you must specify 3 / 2 = 1.5 =&gt; 2 rows, selecting field CELLS_1_2 in first row  and CELLS_3_4 in second row.<br></td></tr
><tr
id=sl_svn220_309

><td class="source">//             There is no need filling a third row because there is no cell 5 or 6<br></td></tr
><tr
id=sl_svn220_310

><td class="source">//    You can say that both must be sent as CELLS_FIRST_ID  like this<br></td></tr
><tr
id=sl_svn220_311

><td class="source">//                          CELLS_FIRST_ID , CELLS_1_2 , 1, 1 ,\<br></td></tr
><tr
id=sl_svn220_312

><td class="source">//                          CELLS_FIRST_ID , CELLS_3_4 , 1, 1<br></td></tr
><tr
id=sl_svn220_313

><td class="source">// *********************************************************************<br></td></tr
><tr
id=sl_svn220_314

><td class="source">//  IMPORTANT : keep always the line &quot;#define SETUP_DATA_TO_SEND    \&quot;  ; do not insert any comment lines after or between the rows used for the set up.<br></td></tr
><tr
id=sl_svn220_315

><td class="source">/*<br></td></tr
><tr
id=sl_svn220_316

><td class="source">*/<br></td></tr
><tr
id=sl_svn220_317

><td class="source">#define SETUP_DATA_TO_SEND    \<br></td></tr
><tr
id=sl_svn220_318

><td class="source">                        DEFAULTFIELD , ALTIMETER , 1 , 1 , 0 ,\<br></td></tr
><tr
id=sl_svn220_319

><td class="source">                        DEFAULTFIELD , VERTICAL_SPEED , 1 , 1 ,0 , \<br></td></tr
><tr
id=sl_svn220_320

><td class="source">                        T1_FIRST_ID , ALT_OVER_10_SEC , 1 , 1,  0<br></td></tr
><tr
id=sl_svn220_321

><td class="source"> //                       DEFAULTFIELD , CURRENTMA , 10 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_322

><td class="source"> //                       FUEL_FIRST_ID , MILLIAH, -100 , 390 , 100, \<br></td></tr
><tr
id=sl_svn220_323

><td class="source"> //                       CELLS_FIRST_ID , CELLS_1_2 , 1, 1 , 0<br></td></tr
><tr
id=sl_svn220_324

><td class="source"><br></td></tr
><tr
id=sl_svn220_325

><td class="source"><br></td></tr
><tr
id=sl_svn220_326

><td class="source">/* Here some typical values for Hub protocol<br></td></tr
><tr
id=sl_svn220_327

><td class="source">#define SETUP_DATA_TO_SEND    \<br></td></tr
><tr
id=sl_svn220_328

><td class="source">                        DEFAULTFIELD , ALTIMETER , 1 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_329

><td class="source">                        DEFAULTFIELD , VERTICAL_SPEED , 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_330

><td class="source">                        DEFAULTFIELD , CURRENTMA , 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_331

><td class="source">                        DEFAULTFIELD , CELLS_1_2 , 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_332

><td class="source">                        DEFAULTFIELD , CELLS_3_4 , 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_333

><td class="source">                        DEFAULTFIELD , RPM , 1 , 1 ,  0,\<br></td></tr
><tr
id=sl_svn220_334

><td class="source">                        FRSKY_USERDATA_TEMP1 , VOLT1, 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_335

><td class="source">                        FRSKY_USERDATA_TEMP2 , VOLT2, 1 , 1 , 0, \<br></td></tr
><tr
id=sl_svn220_336

><td class="source">                        FRSKY_USERDATA_FUEL , MILLIAH , 1, 1 , 0<br></td></tr
><tr
id=sl_svn220_337

><td class="source">*/<br></td></tr
><tr
id=sl_svn220_338

><td class="source"><br></td></tr
><tr
id=sl_svn220_339

><td class="source">/* Here some typical values for SPORT protocol<br></td></tr
><tr
id=sl_svn220_340

><td class="source"><br></td></tr
><tr
id=sl_svn220_341

><td class="source">#define SETUP_DATA_TO_SEND    \<br></td></tr
><tr
id=sl_svn220_342

><td class="source">                        ALT_FIRST_ID , ALTIMETER , 1 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_343

><td class="source">                        VARIO_FIRST_ID , VERTICAL_SPEED , 1 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_344

><td class="source">                        CELLS_FIRST_ID , CELLS_1_2 , 1, 1 , 0,\<br></td></tr
><tr
id=sl_svn220_345

><td class="source">                        CELLS_SECOND_ID , CELLS_3_4 , 1, 1,  0,\   <br></td></tr
><tr
id=sl_svn220_346

><td class="source">                        T1_FIRST_ID , VOLT4 , 1 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_347

><td class="source">                        VFAS_FIRST_ID , VOLT2 , 10 , 1 , 0,\<br></td></tr
><tr
id=sl_svn220_348

><td class="source">                        CURR_FIRST_ID , VOLT3 , 1, 1 ,  0,\<br></td></tr
><tr
id=sl_svn220_349

><td class="source">                        T1_FIRST_ID , ALT_OVER_10_SEC , 1 , 1,  0<br></td></tr
><tr
id=sl_svn220_350

><td class="source">                       <br></td></tr
><tr
id=sl_svn220_351

><td class="source">*/<br></td></tr
><tr
id=sl_svn220_352

><td class="source"> <br></td></tr
><tr
id=sl_svn220_353

><td class="source"><br></td></tr
><tr
id=sl_svn220_354

><td class="source">//**** 4 - Set up for vario ****************************************************************************************<br></td></tr
><tr
id=sl_svn220_355

><td class="source">// 4.1 Connecting a MS5611 barometric sensor is an optional feature<br></td></tr
><tr
id=sl_svn220_356

><td class="source">//     It can calculate the relative altitude (in meter) and the vertical speed (in meter/sec with 2 decimals)<br></td></tr
><tr
id=sl_svn220_357

><td class="source">//     Uncomment the line &quot;#define VARIO&quot; to enable this feature.<br></td></tr
><tr
id=sl_svn220_358

><td class="source">//     When a vario is used, Arduino can take care of some parameters to adjust sensitivity and hysteresis                                       <br></td></tr
><tr
id=sl_svn220_359

><td class="source">//     Sensitivity can be set between                                                                 <br></td></tr
><tr
id=sl_svn220_360

><td class="source">//           20 (conservative setting, reaction time = several seconds)                     <br></td></tr
><tr
id=sl_svn220_361

><td class="source">//           150 (fast but lot of errors, reaction time = much less than a second)       <br></td></tr
><tr
id=sl_svn220_362

><td class="source">//        40 is a normal setting when measuring small vertical speed (search for lift with a glider)<br></td></tr
><tr
id=sl_svn220_363

><td class="source">//     Sensitivity can be predefined by program and/or adjusted from TX<br></td></tr
><tr
id=sl_svn220_364

><td class="source">// 4.2 Sensitivity predefined by program  <br></td></tr
><tr
id=sl_svn220_365

><td class="source">//     Set up uses 4 parameters:                                                      <br></td></tr
><tr
id=sl_svn220_366

><td class="source">//        SENSIVITY_MIN = sensivity being used when vertical speed is lower than VSPEED_MIN ; typical value is 40                        <br></td></tr
><tr
id=sl_svn220_367

><td class="source">//        SENSIVITY_MAX = sensivity being used when vertical speed is higher than VSPEED_MAX ; typical value is 100<br></td></tr
><tr
id=sl_svn220_368

><td class="source">//                     SENSITIVITY_MAX can be set equal to MIN when higher sensitivity for high Vspd is unwanted  <br></td></tr
><tr
id=sl_svn220_369

><td class="source">//        VSPEED_MIN = Sensivity min applies when vertical speed is lower than this value (cm/s); typical value is 20 (cm/sec) <br></td></tr
><tr
id=sl_svn220_370

><td class="source">//        VSPEED_MAX = Sensivity max applies when vertical speed is higher than this value (cm/s); typical value is 100 (cm/sec) <br></td></tr
><tr
id=sl_svn220_371

><td class="source">//           Sensivity is automatically interpolated between VSPEED_MIN ans VSPEED_MAX<br></td></tr
><tr
id=sl_svn220_372

><td class="source">// 4.3 Sensitivity adjusted from the Tx using a switch and/or a potentiometer and a servo channel.<br></td></tr
><tr
id=sl_svn220_373

><td class="source">//     In this case, a servo pin from Rx has to be connected to Arduino (see PPM in hardware section)<br></td></tr
><tr
id=sl_svn220_374

><td class="source">//     Set up uses 4 parameters<br></td></tr
><tr
id=sl_svn220_375

><td class="source">//         PPM_RANGE_MIN    = the total range min of the ppm input (Pulse legth in microseconds ); typical value is 981<br></td></tr
><tr
id=sl_svn220_376

><td class="source">//         PPM_RANGE_MAX 1999  // the total range max of the ppm input (Pulse legth in microseconds ) ; typical value is 1999<br></td></tr
><tr
id=sl_svn220_377

><td class="source">//                The SENSIVITY_PPM_MIN+MAX Parameters define the range in wehich you will be able to adjust <br></td></tr
><tr
id=sl_svn220_378

><td class="source">//         SENSITIVITY_PPM_MIN     //  the min value for sensitivity; typical value could be 20 <br></td></tr
><tr
id=sl_svn220_379

><td class="source">//         SENSITIVITY_PPM_MAX     //  the max value for sensitivity; typical value could be 100<br></td></tr
><tr
id=sl_svn220_380

><td class="source">//     Note : When Arduino detect a signal from TX, the parameters for the predefined sensitivity are automatically discarded<br></td></tr
><tr
id=sl_svn220_381

><td class="source">// 4.4 Arduino can also apply some hysteresis on vertical speed changes<br></td></tr
><tr
id=sl_svn220_382

><td class="source">//      The parameter allows to avoid that transmitted Vspd changes to often (wich can result in bad sound alerts)<br></td></tr
><tr
id=sl_svn220_383

><td class="source">//      This parameter VARIOHYSTERESIS means that transmitted Vspd will change only if measure VSpd (after filtering) differs from previous transmitted value by more than this parameter<br></td></tr
><tr
id=sl_svn220_384

><td class="source">//     Typical value can be 5  (= 5 cm/s); 0 means no hysteresis<br></td></tr
><tr
id=sl_svn220_385

><td class="source">// 4.5 Arduino can also deliver the vertical speed as an analog signal that has to be connected to A1 or A2 on receiver<br></td></tr
><tr
id=sl_svn220_386

><td class="source">//     This can be useful if you have a receiver that has no digital communication pin (or if it is already used by another sensor)<br></td></tr
><tr
id=sl_svn220_387

><td class="source">//     Additional Hardware is required! read the WiKi if you want to use this<br></td></tr
><tr
id=sl_svn220_388

><td class="source">//     To activate this:<br></td></tr
><tr
id=sl_svn220_389

><td class="source">//     - define the digital pin being used (see hardware section)<br></td></tr
><tr
id=sl_svn220_390

><td class="source">//     - set the min and max limits for the vertical speed (in meter/sec)<br></td></tr
><tr
id=sl_svn220_391

><td class="source">//        - OutputClimbRateMin value or lower will apply 0 Volt to the receiver<br></td></tr
><tr
id=sl_svn220_392

><td class="source">//        - OutputClimbRateMax  value or higher will apply 3.2 Volt to the receiver<br></td></tr
><tr
id=sl_svn220_393

><td class="source">// Note : it is not required to comment the sensitivity, hysteresis and OutputClimbRateMin/Max parameters when a vario is not used (those parameters are just discarded)<br></td></tr
><tr
id=sl_svn220_394

><td class="source">//*******************************************************************************************************************<br></td></tr
><tr
id=sl_svn220_395

><td class="source">#define VARIO // set as comment if there is no vario <br></td></tr
><tr
id=sl_svn220_396

><td class="source"><br></td></tr
><tr
id=sl_svn220_397

><td class="source">#define SENSITIVITY_MIN 50 <br></td></tr
><tr
id=sl_svn220_398

><td class="source">#define SENSITIVITY_MAX 50 <br></td></tr
><tr
id=sl_svn220_399

><td class="source">#define VSPEED_MIN 20<br></td></tr
><tr
id=sl_svn220_400

><td class="source">#define VSPEED_MAX 100<br></td></tr
><tr
id=sl_svn220_401

><td class="source"><br></td></tr
><tr
id=sl_svn220_402

><td class="source">#define PPM_RANGE_MIN 981<br></td></tr
><tr
id=sl_svn220_403

><td class="source">#define PPM_RANGE_MAX 1999<br></td></tr
><tr
id=sl_svn220_404

><td class="source">#define SENSITIVITY_PPM_MIN  20<br></td></tr
><tr
id=sl_svn220_405

><td class="source">#define SENSITIVITY_PPM_MAX 100<br></td></tr
><tr
id=sl_svn220_406

><td class="source"><br></td></tr
><tr
id=sl_svn220_407

><td class="source">#define VARIOHYSTERESIS 5<br></td></tr
><tr
id=sl_svn220_408

><td class="source"><br></td></tr
><tr
id=sl_svn220_409

><td class="source">#define OutputClimbRateMin -3 <br></td></tr
><tr
id=sl_svn220_410

><td class="source">#define OutputClimbRateMax  3 <br></td></tr
><tr
id=sl_svn220_411

><td class="source"><br></td></tr
><tr
id=sl_svn220_412

><td class="source"><br></td></tr
><tr
id=sl_svn220_413

><td class="source">//**** 5 Set up for current sensor &amp; 6 voltages **************************************************************************************<br></td></tr
><tr
id=sl_svn220_414

><td class="source">//**** 5.1 - Select the reference (VCC or 1.1 internal voltage reference) ************************************************************<br></td></tr
><tr
id=sl_svn220_415

><td class="source">// Curent and Voltages can be measured in (1023) steps from or VCC or an 1.1 internal reference.<br></td></tr
><tr
id=sl_svn220_416

><td class="source">// If VCC is very stable, it is probably more accurate and easier to measure current and voltages based on VCC (so in 1023 steps from VCC).<br></td></tr
><tr
id=sl_svn220_417

><td class="source">//     Still this requires that the voltage applied on arduino &quot;RAW&quot; pin is or regulated or at at least always more than 5.5 volt (in order to let the arduino board voltage regulate it at 5 volt).<br></td></tr
><tr
id=sl_svn220_418

><td class="source">//     If voltage on &quot;Raw&quot; pin is less than 5.5 volt and changes (e.g. due to servo consumption or low battery) then current and voltage measurements will become wrong.    <br></td></tr
><tr
id=sl_svn220_419

><td class="source">// If VCC can&#39;t be very stable (e.g. arduino is powered via RX by a 4.8 NiMh) and you need only the voltages (no need for the current measurement), then it is possible to measure based on an arduino 1.1 internal voltage reference.<br></td></tr
><tr
id=sl_svn220_420

><td class="source">//     If you need current measurement too, using internal voltage is not &quot;the&quot; solution because current sensor need stable voltage too.<br></td></tr
><tr
id=sl_svn220_421

><td class="source">// Take care that voltage dividers (see below) must be calculated in order that arduino analog pin voltage do not exceed or VCC or 1.1 volt depending on the option you choice.   <br></td></tr
><tr
id=sl_svn220_422

><td class="source">// Uncomment the &quot;#define USE_INTERNAL_REFERENCE&quot; to activate the 1.1 internal voltage reference (otherwise, measurements will be based on VCC)<br></td></tr
><tr
id=sl_svn220_423

><td class="source">//***************************************************************************************<br></td></tr
><tr
id=sl_svn220_424

><td class="source">//#define USE_INTERNAL_REFERENCE<br></td></tr
><tr
id=sl_svn220_425

><td class="source"><br></td></tr
><tr
id=sl_svn220_426

><td class="source"><br></td></tr
><tr
id=sl_svn220_427

><td class="source">//**** 5.2 Calibration parameters for current sensor ************************************************************<br></td></tr
><tr
id=sl_svn220_428

><td class="source">// Connecting a current sensor is on optional feature<br></td></tr
><tr
id=sl_svn220_429

><td class="source">// It requires some additionnal hardware. It can be an IC like ACS712 (for 5, 20, 30 amp) or ACS758 (for 50, 100, 150, 200 amp).<br></td></tr
><tr
id=sl_svn220_430

><td class="source">// Most sensors can read bidirectional currents but ACS758 has &quot;U&quot; types that read only unidirectional current (providing then an higher sensitivity)<br></td></tr
><tr
id=sl_svn220_431

><td class="source">// Current sensor has normally to be calibrated based on 2 parameters :<br></td></tr
><tr
id=sl_svn220_432

><td class="source">//    offsetCurrentSteps  =  Offset to apply for current; normal value is 1024/2 for a bidirectional sensor because 0 Amp gives VCC/2 (or 1.1 V/2 when using a divider)<br></td></tr
><tr
id=sl_svn220_433

><td class="source">//                           Still for unidirectional sensor, voltage at 0 amp is 0.6 volt for 5 volt Vcc; so offset should then normally be 1024 * 0.6 /5 = 123 <br></td></tr
><tr
id=sl_svn220_434

><td class="source">//    mAmpPerStep         =  milliAmp per step from Analoge to Digital Converter; the value depend on the sensitivity of the sensor (and on an eventual voltage divider)<br></td></tr
><tr
id=sl_svn220_435

><td class="source">//                           The value is normally = V (in mvolt) / (sensitivity in mv/Amp * 1.023) where:<br></td></tr
><tr
id=sl_svn220_436

><td class="source">//                                 V is or Vcc (e.g. 5000) or interna 1.1 ref (e.g. 1100) depending on the reference you use<br></td></tr
><tr
id=sl_svn220_437

><td class="source">//                                 sensitivity is normally given in the datasheet from your sensor.<br></td></tr
><tr
id=sl_svn220_438

><td class="source">//                           E.g. for a ACS758LCB-050U, sensitivity is 60 mv/Amp<br></td></tr
><tr
id=sl_svn220_439

><td class="source">//                              So if using 5 volt Vcc =&gt; 5000 / (60 * 1.023) = 81.5 <br></td></tr
><tr
id=sl_svn220_440

><td class="source">// Uncomment the #define PIN_CurrentSensor (see Hardware section) to enable the current sensor<br></td></tr
><tr
id=sl_svn220_441

><td class="source">// note : those parameters are automatically discarded when PIN-CurrentSensor is not defined (= set as comment)<br></td></tr
><tr
id=sl_svn220_442

><td class="source">//***************************************************************************************<br></td></tr
><tr
id=sl_svn220_443

><td class="source">#define offsetCurrentSteps         0    // 66mv offset (set to zero for now)<br></td></tr
><tr
id=sl_svn220_444

><td class="source">#define mAmpPerStep                0.9775   // INA282 with 0.1 ohm shunt gives 5000mv/A     <br></td></tr
><tr
id=sl_svn220_445

><td class="source"><br></td></tr
><tr
id=sl_svn220_446

><td class="source"><br></td></tr
><tr
id=sl_svn220_447

><td class="source">//***** 5.3 - Calibration parameters for voltage measurements *****************************************************<br></td></tr
><tr
id=sl_svn220_448

><td class="source">// For each of the 6 voltages, you can set up an offset and a ratio mVolt per ADC step<br></td></tr
><tr
id=sl_svn220_449

><td class="source">// The set up is specific for each Arduino and depends mainly on the resistors used as divider (and so on the reference being used)<br></td></tr
><tr
id=sl_svn220_450

><td class="source">// <br></td></tr
><tr
id=sl_svn220_451

><td class="source">// Arduino can not convert a voltage that exceed the reference (Vcc or 1.1 volt) being used.<br></td></tr
><tr
id=sl_svn220_452

><td class="source">// If the voltage to measure exceed this value, it has to be divided (scaled down) using a voltage divider.<br></td></tr
><tr
id=sl_svn220_453

><td class="source">// For each voltage to scale down, proceed as follow:<br></td></tr
><tr
id=sl_svn220_454

><td class="source">// - make a divider with 2 resistors <br></td></tr
><tr
id=sl_svn220_455

><td class="source"><br></td></tr
><tr
id=sl_svn220_456

><td class="source">//                 ------&gt;  End point  = connect to the device to measure (battery, Currentsensor, ...) <br></td></tr
><tr
id=sl_svn220_457

><td class="source">//                 |<br></td></tr
><tr
id=sl_svn220_458

><td class="source">//               __|__   <br></td></tr
><tr
id=sl_svn220_459

><td class="source">//              |     |<br></td></tr
><tr
id=sl_svn220_460

><td class="source">//              |     |   R2           <br></td></tr
><tr
id=sl_svn220_461

><td class="source">//              |     |              <br></td></tr
><tr
id=sl_svn220_462

><td class="source">//              |_____|          <br></td></tr
><tr
id=sl_svn220_463

><td class="source">//                 |<br></td></tr
><tr
id=sl_svn220_464

><td class="source">//                 |------&gt; mid point = connect to Arduino pin A0,A1,A2,A3, A6 or A7<br></td></tr
><tr
id=sl_svn220_465

><td class="source">//               __|__   <br></td></tr
><tr
id=sl_svn220_466

><td class="source">//              |     |<br></td></tr
><tr
id=sl_svn220_467

><td class="source">//              |     |   R1          <br></td></tr
><tr
id=sl_svn220_468

><td class="source">//              |     |              <br></td></tr
><tr
id=sl_svn220_469

><td class="source">//              |_____|          <br></td></tr
><tr
id=sl_svn220_470

><td class="source">//                 |<br></td></tr
><tr
id=sl_svn220_471

><td class="source">//                 ------&gt;  connect to Ground<br></td></tr
><tr
id=sl_svn220_472

><td class="source">//<br></td></tr
><tr
id=sl_svn220_473

><td class="source">// - R1 and R2 are choosen to make sure that voltage apply to Arduino is quiet close to ( but never exceed) VCC or 1.1 volt depending on your choice regarding the current &amp; voltage measurement (see here above)<br></td></tr
><tr
id=sl_svn220_474

><td class="source">// - Volt on Arduino pin = VCC (or 1.1 volt) = &quot;max voltage to measure from this sensor&quot; * R1 / (R1 + R2)<br></td></tr
><tr
id=sl_svn220_475

><td class="source">// - R1 could be 10 kOhm; so R2 = R1 * ( ( &quot;max voltage to measure from this sensor&quot;  / VCC [or 1.1 depending on the reference] ) - 1 )<br></td></tr
><tr
id=sl_svn220_476

><td class="source">//    e.g. using 1.1 internal voltage reference and in order to measure max 6 volt with R1 = 10000, then R2 = 10000 * (( 6 / 1.1 ) - 1) = 45545 Ohm; best rounded up to high available value e.g 47000 ohm<br></td></tr
><tr
id=sl_svn220_477

><td class="source">//<br></td></tr
><tr
id=sl_svn220_478

><td class="source">// Due to errors on resistor, on Vcc or 1.1 volt reference and on ADC it is required, for best result, to calibrate each voltage measurement as follow:<br></td></tr
><tr
id=sl_svn220_479

><td class="source">// - set parameters in oxs_config.h  :<br></td></tr
><tr
id=sl_svn220_480

><td class="source">//            - choice to measure based on VCC or 1.1 internal voltage (and (un)comment line &quot;#define USE_INTERNAL_REFERENCE&quot;<br></td></tr
><tr
id=sl_svn220_481

><td class="source">//            - set first offset = 0 (default values)<br></td></tr
><tr
id=sl_svn220_482

><td class="source">//            - set first mVoltPerStep = 1 (default values)<br></td></tr
><tr
id=sl_svn220_483

><td class="source">//            - select a field to transmit the desired voltage and fill the line  &quot;#define SETUP_DATA_TO_SEND&quot; accordingly <br></td></tr
><tr
id=sl_svn220_484

><td class="source">// - load the program in Arduino <br></td></tr
><tr
id=sl_svn220_485

><td class="source">// - apply several different voltages on End point (not exceeding the max voltage allowed based on R1 and R2)<br></td></tr
><tr
id=sl_svn220_486

><td class="source">// - for each applied voltage, measure the applied voltage with a voltmeter and read the value received on telemetry panel on Tx<br></td></tr
><tr
id=sl_svn220_487

><td class="source">// - set the values in excel (or on a graphic) and calculate the best values for mVoltPerStep and offset (using a linear regression)<br></td></tr
><tr
id=sl_svn220_488

><td class="source">//     If this seems to complex, just use 2 voltages as different as possible (but in the range of the normal values you want to measure)<br></td></tr
><tr
id=sl_svn220_489

><td class="source">//     and apply calculation based on following example:        .<br></td></tr
><tr
id=sl_svn220_490

><td class="source">//     I expect voltage to be normally between 4 volt and 6 volt, so I apply 2 voltages close to those values to End point<br></td></tr
><tr
id=sl_svn220_491

><td class="source">//       - for first voltage, voltmeter gives 3510 millivolt and telemetry gives 533<br></td></tr
><tr
id=sl_svn220_492

><td class="source">//       - for secong voltage, voltmeter gives 5900 millivolt and telemetry gives 904<br></td></tr
><tr
id=sl_svn220_493

><td class="source">//    So mVoltPerStep = (5900-3510) / (904-533) = 6.4420<br></td></tr
><tr
id=sl_svn220_494

><td class="source">//    So offset = 3510 - (533 * 6.4420 ) = 76<br></td></tr
><tr
id=sl_svn220_495

><td class="source">//  Note : when some pins are not used for voltage measurement, apply default values    <br></td></tr
><tr
id=sl_svn220_496

><td class="source">//#define offset_1             0        // Offset to apply for first voltage (= voltage 1) (default value = 0)<br></td></tr
><tr
id=sl_svn220_497

><td class="source">//#define mVoltPerStep_1       1        // millivolt per step from Analoge to Digital Converter for first voltage (initial calibration value = 1)<br></td></tr
><tr
id=sl_svn220_498

><td class="source">//#define offset_2             0        // Offset to apply for second voltage <br></td></tr
><tr
id=sl_svn220_499

><td class="source">//#define mVoltPerStep_2       1        // millivolt per step from Analoge to Digital Converter for second voltage<br></td></tr
><tr
id=sl_svn220_500

><td class="source">// etc ... up to 6<br></td></tr
><tr
id=sl_svn220_501

><td class="source">//******************************************************************************************<br></td></tr
><tr
id=sl_svn220_502

><td class="source">#define offset_1             0   <br></td></tr
><tr
id=sl_svn220_503

><td class="source">#define mVoltPerStep_1       4.89 // = 5000 / 1023 (if Vcc =5 volt)     <br></td></tr
><tr
id=sl_svn220_504

><td class="source">#define offset_2             0    <br></td></tr
><tr
id=sl_svn220_505

><td class="source">#define mVoltPerStep_2       1    <br></td></tr
><tr
id=sl_svn220_506

><td class="source">#define offset_3             0       <br></td></tr
><tr
id=sl_svn220_507

><td class="source">#define mVoltPerStep_3       1<br></td></tr
><tr
id=sl_svn220_508

><td class="source">#define offset_4             0        <br></td></tr
><tr
id=sl_svn220_509

><td class="source">#define mVoltPerStep_4       1        <br></td></tr
><tr
id=sl_svn220_510

><td class="source">#define offset_5             0        <br></td></tr
><tr
id=sl_svn220_511

><td class="source">#define mVoltPerStep_5       1        <br></td></tr
><tr
id=sl_svn220_512

><td class="source">#define offset_6             0        <br></td></tr
><tr
id=sl_svn220_513

><td class="source">#define mVoltPerStep_6       1        <br></td></tr
><tr
id=sl_svn220_514

><td class="source"><br></td></tr
><tr
id=sl_svn220_515

><td class="source">//**** 5.4 Number of Lipo cell to measure  (and transmit to Tx) *********************************************************************<br></td></tr
><tr
id=sl_svn220_516

><td class="source">//     The different voltages measured under 5.3 are all related to the ground.<br></td></tr
><tr
id=sl_svn220_517

><td class="source">//     Arduino can use some of them to calculate the voltage of some lipo cell<br></td></tr
><tr
id=sl_svn220_518

><td class="source">//     Define here the number of cell voltages of a lipo you want to transmit; value can be 0 (no cells),1,2,3,4,5,6<br></td></tr
><tr
id=sl_svn220_519

><td class="source">//     If a value greater than 1 is defined, then the Arduino will calculate the voltage of each cell based on the difference between 2 succesive voltages starting from Voltage1.<br></td></tr
><tr
id=sl_svn220_520

><td class="source">//     The total voltage of all cells wil be calculated on TX side summing all cell voltages again.<br></td></tr
><tr
id=sl_svn220_521

><td class="source">//     TX will display the total voltage in a telemetry field named &quot;Cells&quot;<br></td></tr
><tr
id=sl_svn220_522

><td class="source">//     TX will also identify the cell with the lowest voltage and display it in a field named &quot;Cell&quot;<br></td></tr
><tr
id=sl_svn220_523

><td class="source">//     TX has also a special screen where all voltages will be displayed (see Taranis manual)<br></td></tr
><tr
id=sl_svn220_524

><td class="source">//     E.g. if number of cells = 3, <br></td></tr
><tr
id=sl_svn220_525

><td class="source">//           voltage on cell 1 will be voltage measured on PIN_Voltage1<br></td></tr
><tr
id=sl_svn220_526

><td class="source">//           voltage on cell 2 will be the difference between voltages measure on PIN_Voltage2 and PIN_Voltage1<br></td></tr
><tr
id=sl_svn220_527

><td class="source">//           voltage on cell 3 will be the difference between voltages measure on PIN_Voltage3 and PIN_Voltage2<br></td></tr
><tr
id=sl_svn220_528

><td class="source">//           etc...<br></td></tr
><tr
id=sl_svn220_529

><td class="source">//    When transmitting cell voltages, you may NOT FORGET TO CONFIGURE the PIN_Voltage and to configure the calibration parameters too .<br></td></tr
><tr
id=sl_svn220_530

><td class="source">//    Pins voltage in excess may be used in order to transmit other voltages (e.g. from a temperature sensor)<br></td></tr
><tr
id=sl_svn220_531

><td class="source">//    E.g. if NUMBEROFCELLS = 3, PIN_Voltage 1 must be connected to cell 1 (via a voltage divider calculated for about 4.5 volt<br></td></tr
><tr
id=sl_svn220_532

><td class="source">//                               PIN_Voltage 2 must be connected to cell 2 (via a voltage divider calculated for about 9 volt<br></td></tr
><tr
id=sl_svn220_533

><td class="source">//                               PIN_Voltage 3 must be connected to cell 3 (via a voltage divider calculated for about 13 volt<br></td></tr
><tr
id=sl_svn220_534

><td class="source">//                               PIN_Voltage 4, 5 and/or 6 may still be used for other data (temperature, current, ...)<br></td></tr
><tr
id=sl_svn220_535

><td class="source">//    Note : You must use voltage dividers to scale down the voltages on each pin of the lipo balance plug<br></td></tr
><tr
id=sl_svn220_536

><td class="source">//           If you use the 1.1 internal reference, you can set all R1 = 10 kOhm. Then R2 could best be<br></td></tr
><tr
id=sl_svn220_537

><td class="source">//                  33 kOhm for Voltage1, 68 kOhm for Voltage2, 120 kOhm for Voltage3 and 150 kOhm for voltage4<br></td></tr
><tr
id=sl_svn220_538

><td class="source">//           Please note that the more cells you have the more unaccurate the measurements become.<br></td></tr
><tr
id=sl_svn220_539

><td class="source">//           Probably, it make no sense to measure more that 3 or 4 cells individually<br></td></tr
><tr
id=sl_svn220_540

><td class="source">//*****************************************************************************<br></td></tr
><tr
id=sl_svn220_541

><td class="source">#define NUMBEROFCELLS 0  // keep this line but set value to 0 (zero) if you do not want to transmit cell voltage.<br></td></tr
><tr
id=sl_svn220_542

><td class="source"><br></td></tr
><tr
id=sl_svn220_543

><td class="source"><br></td></tr
><tr
id=sl_svn220_544

><td class="source">//**** 6 - Set up for RPM (rotation per minute) ********************************************************************************<br></td></tr
><tr
id=sl_svn220_545

><td class="source">//    Optional Feature.<br></td></tr
><tr
id=sl_svn220_546

><td class="source">//    It is possible to measure RPM using a sensor connected to pin ICP (=PB0) of arduino.<br></td></tr
><tr
id=sl_svn220_547

><td class="source">//    This sensor must provide a level change (0 - 5 volt) on this pin each time a blade goes before the sensor.<br></td></tr
><tr
id=sl_svn220_548

><td class="source">//    The number of blades is an important paramater to set up but this is done on Tx side<br></td></tr
><tr
id=sl_svn220_549

><td class="source">//    To activate this function, uncomment the #define MEASURE_RPM line here under.<br></td></tr
><tr
id=sl_svn220_550

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_551

><td class="source">//#define MEASURE_RPM	1<br></td></tr
><tr
id=sl_svn220_552

><td class="source"><br></td></tr
><tr
id=sl_svn220_553

><td class="source"><br></td></tr
><tr
id=sl_svn220_554

><td class="source"><br></td></tr
><tr
id=sl_svn220_555

><td class="source">//**** 7 - Set up of Persistent memory *********************************************************************************<br></td></tr
><tr
id=sl_svn220_556

><td class="source">// Optional Feature                                                <br></td></tr
><tr
id=sl_svn220_557

><td class="source">// If defined, some telemetry values will be stored in EEProm every 10 seconds.        <br></td></tr
><tr
id=sl_svn220_558

><td class="source">// These values will be restored every powerup. (e.g. mAh counted...)<br></td></tr
><tr
id=sl_svn220_559

><td class="source">// By doing this we will get ongoing data counts even if the you turn off the modell   <br></td></tr
><tr
id=sl_svn220_560

><td class="source">// between flights            <br></td></tr
><tr
id=sl_svn220_561

><td class="source">// Uncomment the line &quot;#define SAVE_TO_EEPROM&quot; to activate the persistent storage <br></td></tr
><tr
id=sl_svn220_562

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_563

><td class="source">//#define SAVE_TO_EEPROM      <br></td></tr
><tr
id=sl_svn220_564

><td class="source"><br></td></tr
><tr
id=sl_svn220_565

><td class="source"><br></td></tr
><tr
id=sl_svn220_566

><td class="source"><br></td></tr
><tr
id=sl_svn220_567

><td class="source">//**** 9 Reserve for developer. *********************************************************************************<br></td></tr
><tr
id=sl_svn220_568

><td class="source">// DEBUG must be activated here when we want to debug one or several functions in some other files.<br></td></tr
><tr
id=sl_svn220_569

><td class="source"><br></td></tr
><tr
id=sl_svn220_570

><td class="source">//#define DEBUG<br></td></tr
><tr
id=sl_svn220_571

><td class="source"><br></td></tr
><tr
id=sl_svn220_572

><td class="source">#ifdef DEBUG<br></td></tr
><tr
id=sl_svn220_573

><td class="source">#include &quot;HardwareSerial.h&quot;<br></td></tr
><tr
id=sl_svn220_574

><td class="source">#endif<br></td></tr
><tr
id=sl_svn220_575

><td class="source"><br></td></tr
><tr
id=sl_svn220_576

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_577

><td class="source">// do not modify those lines<br></td></tr
><tr
id=sl_svn220_578

><td class="source">#ifdef PIN_PPM<br></td></tr
><tr
id=sl_svn220_579

><td class="source"> #if PIN_PPM == 2<br></td></tr
><tr
id=sl_svn220_580

><td class="source">	#define PPM_INTERRUPT			ON // define to use interrupt code in Aserial.cpp<br></td></tr
><tr
id=sl_svn220_581

><td class="source"><br></td></tr
><tr
id=sl_svn220_582

><td class="source">	#define PPM_INT_MASK			3<br></td></tr
><tr
id=sl_svn220_583

><td class="source">	#define PPM_INT_EDGE			1<br></td></tr
><tr
id=sl_svn220_584

><td class="source">	#define PPM_PIN_HEX				0x02<br></td></tr
><tr
id=sl_svn220_585

><td class="source">	#define PPM_INT_BIT				0x01<br></td></tr
><tr
id=sl_svn220_586

><td class="source"> #endif<br></td></tr
><tr
id=sl_svn220_587

><td class="source"><br></td></tr
><tr
id=sl_svn220_588

><td class="source"> #if PIN_PPM == 3<br></td></tr
><tr
id=sl_svn220_589

><td class="source">	#define PPM_INTERRUPT			ON // define to use interrupt code in Aserial.cpp<br></td></tr
><tr
id=sl_svn220_590

><td class="source">	#define PPM_INT_MASK			0x0C<br></td></tr
><tr
id=sl_svn220_591

><td class="source">	#define PPM_INT_EDGE			0x04<br></td></tr
><tr
id=sl_svn220_592

><td class="source">	#define PPM_PIN_HEX				0x04<br></td></tr
><tr
id=sl_svn220_593

><td class="source">	#define PPM_INT_BIT				0x02<br></td></tr
><tr
id=sl_svn220_594

><td class="source"> #endif<br></td></tr
><tr
id=sl_svn220_595

><td class="source">#endif<br></td></tr
><tr
id=sl_svn220_596

><td class="source"><br></td></tr
><tr
id=sl_svn220_597

><td class="source"><br></td></tr
><tr
id=sl_svn220_598

><td class="source">//*************** There is normally no reason changing the 2 next parameters<br></td></tr
><tr
id=sl_svn220_599

><td class="source">#define I2CAdd           0x77 // 0x77 The I2C Address of the MS5611 breakout board <br></td></tr
><tr
id=sl_svn220_600

><td class="source">                               // (normally 0x76 or 0x77 configured on the MS5611 module <br></td></tr
><tr
id=sl_svn220_601

><td class="source">                               // via a solder pin or fixed)<br></td></tr
><tr
id=sl_svn220_602

><td class="source">                               <br></td></tr
><tr
id=sl_svn220_603

><td class="source">#define PIN_LED            13  // The Signal LED (default=13=onboard LED)<br></td></tr
><tr
id=sl_svn220_604

><td class="source"><br></td></tr
><tr
id=sl_svn220_605

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_606

><td class="source">// Other Configuration Options  =&gt; various different values to take influence on       <br></td></tr
><tr
id=sl_svn220_607

><td class="source">//                    various stuff. Normaly you do not have to change any of these    <br></td></tr
><tr
id=sl_svn220_608

><td class="source">//*************************************************************************************<br></td></tr
><tr
id=sl_svn220_609

><td class="source">//#define FORCE_ABSOLUTE_ALT // If defined, the height offset in open9x will be resetted upon startup, which results <br></td></tr
><tr
id=sl_svn220_610

><td class="source">// in an absolute height display in open9x . (You can still change to a relative display <br></td></tr
><tr
id=sl_svn220_611

><td class="source">// by pressing [MENU] in the telem.screens<br></td></tr
><tr
id=sl_svn220_612

><td class="source">// If not defined, open9x will use the first transmitted altitude as an internal offset, <br></td></tr
><tr
id=sl_svn220_613

><td class="source">// which results in an initial height of 0m<br></td></tr
><tr
id=sl_svn220_614

><td class="source">// !!!!!!!!! Not sure that this works in this version !!!!!!!!!!!!!!<br></td></tr
><tr
id=sl_svn220_615

><td class="source"><br></td></tr
><tr
id=sl_svn220_616

><td class="source"><br></td></tr
><tr
id=sl_svn220_617

><td class="source">#endif// End define OXS_CONFIG_h<br></td></tr
></table></pre>
<pre><table width="100%"><tr class="cursor_stop cursor_hidden"><td></td></tr></table></pre>
</td>
</tr></table>

 
<script type="text/javascript">
 var lineNumUnderMouse = -1;
 
 function gutterOver(num) {
 gutterOut();
 var newTR = document.getElementById('gr_svn220_' + num);
 if (newTR) {
 newTR.className = 'undermouse';
 }
 lineNumUnderMouse = num;
 }
 function gutterOut() {
 if (lineNumUnderMouse != -1) {
 var oldTR = document.getElementById(
 'gr_svn220_' + lineNumUnderMouse);
 if (oldTR) {
 oldTR.className = '';
 }
 lineNumUnderMouse = -1;
 }
 }
 var numsGenState = {table_base_id: 'nums_table_'};
 var srcGenState = {table_base_id: 'src_table_'};
 var alignerRunning = false;
 var startOver = false;
 function setLineNumberHeights() {
 if (alignerRunning) {
 startOver = true;
 return;
 }
 numsGenState.chunk_id = 0;
 numsGenState.table = document.getElementById('nums_table_0');
 numsGenState.row_num = 0;
 if (!numsGenState.table) {
 return; // Silently exit if no file is present.
 }
 srcGenState.chunk_id = 0;
 srcGenState.table = document.getElementById('src_table_0');
 srcGenState.row_num = 0;
 alignerRunning = true;
 continueToSetLineNumberHeights();
 }
 function rowGenerator(genState) {
 if (genState.row_num < genState.table.rows.length) {
 var currentRow = genState.table.rows[genState.row_num];
 genState.row_num++;
 return currentRow;
 }
 var newTable = document.getElementById(
 genState.table_base_id + (genState.chunk_id + 1));
 if (newTable) {
 genState.chunk_id++;
 genState.row_num = 0;
 genState.table = newTable;
 return genState.table.rows[0];
 }
 return null;
 }
 var MAX_ROWS_PER_PASS = 1000;
 function continueToSetLineNumberHeights() {
 var rowsInThisPass = 0;
 var numRow = 1;
 var srcRow = 1;
 while (numRow && srcRow && rowsInThisPass < MAX_ROWS_PER_PASS) {
 numRow = rowGenerator(numsGenState);
 srcRow = rowGenerator(srcGenState);
 rowsInThisPass++;
 if (numRow && srcRow) {
 if (numRow.offsetHeight != srcRow.offsetHeight) {
 numRow.firstChild.style.height = srcRow.offsetHeight + 'px';
 }
 }
 }
 if (rowsInThisPass >= MAX_ROWS_PER_PASS) {
 setTimeout(continueToSetLineNumberHeights, 10);
 } else {
 alignerRunning = false;
 if (startOver) {
 startOver = false;
 setTimeout(setLineNumberHeights, 500);
 }
 }
 }
 function initLineNumberHeights() {
 // Do 2 complete passes, because there can be races
 // between this code and prettify.
 startOver = true;
 setTimeout(setLineNumberHeights, 250);
 window.onresize = setLineNumberHeights;
 }
 initLineNumberHeights();
</script>

 
 
 <div id="log">
 <div style="text-align:right">
 <a class="ifCollapse" href="#" onclick="_toggleMeta(this); return false">Show details</a>
 <a class="ifExpand" href="#" onclick="_toggleMeta(this); return false">Hide details</a>
 </div>
 <div class="ifExpand">
 
 
 <div class="pmeta_bubble_bg" style="border:1px solid white">
 <div class="round4"></div>
 <div class="round2"></div>
 <div class="round1"></div>
 <div class="box-inner">
 <div id="changelog">
 <p>Change log</p>
 <div>
 <a href="/p/openxvario/source/detail?spec=svn220&amp;r=208">r208</a>
 by mstrens
 on Jul 13, 2014
 &nbsp; <a href="/p/openxvario/source/diff?spec=svn220&r=208&amp;format=side&amp;path=/branches/openxsensor/oxs_config.h&amp;old_path=/branches/openxsensor/oxs_config.h&amp;old=204">Diff</a>
 </div>
 <pre>Error in the explanation about the way the
parameter mAmpPerStep had to be
calculated.</pre>
 </div>
 
 
 
 
 
 
 <script type="text/javascript">
 var detail_url = '/p/openxvario/source/detail?r=208&spec=svn220';
 var publish_url = '/p/openxvario/source/detail?r=208&spec=svn220#publish';
 // describe the paths of this revision in javascript.
 var changed_paths = [];
 var changed_urls = [];
 
 changed_paths.push('/branches/openxsensor/oxs_config.h');
 changed_urls.push('/p/openxvario/source/browse/branches/openxsensor/oxs_config.h?r\x3d208\x26spec\x3dsvn220');
 
 var selected_path = '/branches/openxsensor/oxs_config.h';
 
 
 function getCurrentPageIndex() {
 for (var i = 0; i < changed_paths.length; i++) {
 if (selected_path == changed_paths[i]) {
 return i;
 }
 }
 }
 function getNextPage() {
 var i = getCurrentPageIndex();
 if (i < changed_paths.length - 1) {
 return changed_urls[i + 1];
 }
 return null;
 }
 function getPreviousPage() {
 var i = getCurrentPageIndex();
 if (i > 0) {
 return changed_urls[i - 1];
 }
 return null;
 }
 function gotoNextPage() {
 var page = getNextPage();
 if (!page) {
 page = detail_url;
 }
 window.location = page;
 }
 function gotoPreviousPage() {
 var page = getPreviousPage();
 if (!page) {
 page = detail_url;
 }
 window.location = page;
 }
 function gotoDetailPage() {
 window.location = detail_url;
 }
 function gotoPublishPage() {
 window.location = publish_url;
 }
</script>

 
 <style type="text/css">
 #review_nav {
 border-top: 3px solid white;
 padding-top: 6px;
 margin-top: 1em;
 }
 #review_nav td {
 vertical-align: middle;
 }
 #review_nav select {
 margin: .5em 0;
 }
 </style>
 <div id="review_nav">
 <table><tr><td>Go to:&nbsp;</td><td>
 <select name="files_in_rev" onchange="window.location=this.value">
 
 <option value="/p/openxvario/source/browse/branches/openxsensor/oxs_config.h?r=208&amp;spec=svn220"
 selected="selected"
 >/branches/openxsensor/oxs_config.h</option>
 
 </select>
 </td></tr></table>
 
 
 



 
 </div>
 
 
 </div>
 <div class="round1"></div>
 <div class="round2"></div>
 <div class="round4"></div>
 </div>
 <div class="pmeta_bubble_bg" style="border:1px solid white">
 <div class="round4"></div>
 <div class="round2"></div>
 <div class="round1"></div>
 <div class="box-inner">
 <div id="older_bubble">
 <p>Older revisions</p>
 
 
 <div class="closed" style="margin-bottom:3px;" >
 <a class="ifClosed" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/plus.gif" ></a>
 <a class="ifOpened" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/minus.gif" ></a>
 <a href="/p/openxvario/source/detail?spec=svn220&r=204">r204</a>
 by mstrens
 on Mar 26, 2014
 &nbsp; <a href="/p/openxvario/source/diff?spec=svn220&r=204&amp;format=side&amp;path=/branches/openxsensor/oxs_config.h&amp;old_path=/branches/openxsensor/oxs_config.h&amp;old=201">Diff</a>
 <br>
 <pre class="ifOpened">Add the possibility generating an
analog signal with Vertical speed
Update of config.h file</pre>
 </div>
 
 <div class="closed" style="margin-bottom:3px;" >
 <a class="ifClosed" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/plus.gif" ></a>
 <a class="ifOpened" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/minus.gif" ></a>
 <a href="/p/openxvario/source/detail?spec=svn220&r=201">r201</a>
 by mstrens
 on Mar 21, 2014
 &nbsp; <a href="/p/openxvario/source/diff?spec=svn220&r=201&amp;format=side&amp;path=/branches/openxsensor/oxs_config.h&amp;old_path=/branches/openxsensor/oxs_config.h&amp;old=197">Diff</a>
 <br>
 <pre class="ifOpened">Major release (better vertical speed,
more voltages , use of internal 1.1
volt ref, more data transmitted to TX
using multiplier, divider and offset,
support SPORT and Hub protocols, ...)</pre>
 </div>
 
 <div class="closed" style="margin-bottom:3px;" >
 <a class="ifClosed" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/plus.gif" ></a>
 <a class="ifOpened" onclick="return _toggleHidden(this)"><img src="https://ssl.gstatic.com/codesite/ph/images/minus.gif" ></a>
 <a href="/p/openxvario/source/detail?spec=svn220&r=197">r197</a>
 by michael....@mypostoffice.co.uk
 on Feb 14, 2014
 &nbsp; <a href="/p/openxvario/source/diff?spec=svn220&r=197&amp;format=side&amp;path=/branches/openxsensor/oxs_config.h&amp;old_path=/branches/openxsensor/oxs_config.h&amp;old=194">Diff</a>
 <br>
 <pre class="ifOpened">SPort byte stuffing, remove many
interrupts, custom millis()/micros(),
add RPM, PPM on IO2 or IO3, code
slimming</pre>
 </div>
 
 
 <a href="/p/openxvario/source/list?path=/branches/openxsensor/oxs_config.h&start=208">All revisions of this file</a>
 </div>
 </div>
 <div class="round1"></div>
 <div class="round2"></div>
 <div class="round4"></div>
 </div>
 
 <div class="pmeta_bubble_bg" style="border:1px solid white">
 <div class="round4"></div>
 <div class="round2"></div>
 <div class="round1"></div>
 <div class="box-inner">
 <div id="fileinfo_bubble">
 <p>File info</p>
 
 <div>Size: 45012 bytes,
 617 lines</div>
 
 <div><a href="//openxvario.googlecode.com/svn/branches/openxsensor/oxs_config.h">View raw file</a></div>
 </div>
 
 </div>
 <div class="round1"></div>
 <div class="round2"></div>
 <div class="round4"></div>
 </div>
 </div>
 </div>


</div>

</div>
</div>

<script src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/prettify/prettify.js"></script>
<script type="text/javascript">prettyPrint();</script>


<script src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/source_file_scripts.js"></script>

 <script type="text/javascript" src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/kibbles.js"></script>
 <script type="text/javascript">
 var lastStop = null;
 var initialized = false;
 
 function updateCursor(next, prev) {
 if (prev && prev.element) {
 prev.element.className = 'cursor_stop cursor_hidden';
 }
 if (next && next.element) {
 next.element.className = 'cursor_stop cursor';
 lastStop = next.index;
 }
 }
 
 function pubRevealed(data) {
 updateCursorForCell(data.cellId, 'cursor_stop cursor_hidden');
 if (initialized) {
 reloadCursors();
 }
 }
 
 function draftRevealed(data) {
 updateCursorForCell(data.cellId, 'cursor_stop cursor_hidden');
 if (initialized) {
 reloadCursors();
 }
 }
 
 function draftDestroyed(data) {
 updateCursorForCell(data.cellId, 'nocursor');
 if (initialized) {
 reloadCursors();
 }
 }
 function reloadCursors() {
 kibbles.skipper.reset();
 loadCursors();
 if (lastStop != null) {
 kibbles.skipper.setCurrentStop(lastStop);
 }
 }
 // possibly the simplest way to insert any newly added comments
 // is to update the class of the corresponding cursor row,
 // then refresh the entire list of rows.
 function updateCursorForCell(cellId, className) {
 var cell = document.getElementById(cellId);
 // we have to go two rows back to find the cursor location
 var row = getPreviousElement(cell.parentNode);
 row.className = className;
 }
 // returns the previous element, ignores text nodes.
 function getPreviousElement(e) {
 var element = e.previousSibling;
 if (element.nodeType == 3) {
 element = element.previousSibling;
 }
 if (element && element.tagName) {
 return element;
 }
 }
 function loadCursors() {
 // register our elements with skipper
 var elements = CR_getElements('*', 'cursor_stop');
 var len = elements.length;
 for (var i = 0; i < len; i++) {
 var element = elements[i]; 
 element.className = 'cursor_stop cursor_hidden';
 kibbles.skipper.append(element);
 }
 }
 function toggleComments() {
 CR_toggleCommentDisplay();
 reloadCursors();
 }
 function keysOnLoadHandler() {
 // setup skipper
 kibbles.skipper.addStopListener(
 kibbles.skipper.LISTENER_TYPE.PRE, updateCursor);
 // Set the 'offset' option to return the middle of the client area
 // an option can be a static value, or a callback
 kibbles.skipper.setOption('padding_top', 50);
 // Set the 'offset' option to return the middle of the client area
 // an option can be a static value, or a callback
 kibbles.skipper.setOption('padding_bottom', 100);
 // Register our keys
 kibbles.skipper.addFwdKey("n");
 kibbles.skipper.addRevKey("p");
 kibbles.keys.addKeyPressListener(
 'u', function() { window.location = detail_url; });
 kibbles.keys.addKeyPressListener(
 'r', function() { window.location = detail_url + '#publish'; });
 
 kibbles.keys.addKeyPressListener('j', gotoNextPage);
 kibbles.keys.addKeyPressListener('k', gotoPreviousPage);
 
 
 }
 </script>
<script src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/code_review_scripts.js"></script>
<script type="text/javascript">
 function showPublishInstructions() {
 var element = document.getElementById('review_instr');
 if (element) {
 element.className = 'opened';
 }
 }
 var codereviews;
 function revsOnLoadHandler() {
 // register our source container with the commenting code
 var paths = {'svn220': '/branches/openxsensor/oxs_config.h'}
 codereviews = CR_controller.setup(
 {"loggedInUserEmail": "viabfer@gmail.com", "assetHostPath": "https://ssl.gstatic.com/codesite/ph", "assetVersionPath": "https://ssl.gstatic.com/codesite/ph/16315335801608708296", "domainName": null, "relativeBaseUrl": "", "token": "ABZ6GAdrqaOtRuoQey-ncYnTETaHeQWmGg:1412118235326", "profileUrl": "/u/114812766044642662008/", "projectHomeUrl": "/p/openxvario", "projectName": "openxvario"}, '', 'svn220', paths,
 CR_BrowseIntegrationFactory);
 
 codereviews.registerActivityListener(CR_ActivityType.REVEAL_DRAFT_PLATE, showPublishInstructions);
 
 codereviews.registerActivityListener(CR_ActivityType.REVEAL_PUB_PLATE, pubRevealed);
 codereviews.registerActivityListener(CR_ActivityType.REVEAL_DRAFT_PLATE, draftRevealed);
 codereviews.registerActivityListener(CR_ActivityType.DISCARD_DRAFT_COMMENT, draftDestroyed);
 
 
 
 
 
 
 
 var initialized = true;
 reloadCursors();
 }
 window.onload = function() {keysOnLoadHandler(); revsOnLoadHandler();};

</script>
<script type="text/javascript" src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/dit_scripts.js"></script>

 
 
 
 <script type="text/javascript" src="https://ssl.gstatic.com/codesite/ph/16315335801608708296/js/ph_core.js"></script>
 
 
 
 
</div> 

<div id="footer" dir="ltr">
 <div class="text">
 <a href="/projecthosting/terms.html">Terms</a> -
 <a href="http://www.google.com/privacy.html">Privacy</a> -
 <a href="/p/support/">Project Hosting Help</a>
 </div>
</div>
 <div class="hostedBy" style="margin-top: -20px;">
 <span style="vertical-align: top;">Powered by <a href="http://code.google.com/projecthosting/">Google Project Hosting</a></span>
 </div>

 
 


 
 </body>
</html>

