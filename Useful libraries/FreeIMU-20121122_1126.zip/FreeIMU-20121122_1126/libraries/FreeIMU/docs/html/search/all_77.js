var searchData=
[
  ['writearr',['writeArr',['../CommunicationUtils_8cpp.html#a72b0db31227aff8bd5295dabc8531319',1,'writeArr(void *varr, uint8_t arr_length, uint8_t type_bytes):&#160;CommunicationUtils.cpp'],['../CommunicationUtils_8h.html#a62ed15091664b2a0e7442db401ac6a79',1,'writeArr(void *arr, uint8_t arr_length, uint8_t type_bytes):&#160;CommunicationUtils.cpp']]],
  ['writevar',['writeVar',['../CommunicationUtils_8cpp.html#abaaae209c6c360cf4be597792cda862a',1,'writeVar(void *val, uint8_t type_bytes):&#160;CommunicationUtils.cpp'],['../CommunicationUtils_8h.html#abaaae209c6c360cf4be597792cda862a',1,'writeVar(void *val, uint8_t type_bytes):&#160;CommunicationUtils.cpp']]]
];
