#ifndef _TESTS_H_ 
#define _TESTS_H_
#include "Colorimeter.h"

void led_cycle_test();
void test_get_frequencies();
extern Colorimeter colorimeter;

#endif
